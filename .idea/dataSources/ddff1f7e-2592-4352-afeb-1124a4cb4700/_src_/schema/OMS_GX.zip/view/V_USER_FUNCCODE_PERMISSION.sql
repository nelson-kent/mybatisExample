CREATE VIEW V_USER_FUNCCODE_PERMISSION AS WITH t_no_permission AS(
               SELECT func_code
               FROM top_per_func
               WHERE func_code IS NOT NULL
                     AND permission_type = 1
                     AND func_node_type IN (2, 3, 4)
                     AND status = 1
          )
          SELECT subject_id user_Id, b.func_code
          FROM v_subject_permission A INNER JOIN
                TOP_PER_FUNC B ON a.resource_id = b.func_id
          WHERE a.subject_classify_code = 'USER' AND a.resource_type_code = 'FUNC'
                AND b.permission_type = 2
                AND b.func_node_type IN (2, 3, 4) AND b.status = 1 AND b.func_code IS NOT NULL
          UNION ALL
          SELECT c.User_Id, d.func_code
          FROM top_user c, t_no_permission d
/
