CREATE VIEW CIP_MODULE_FULLPATH AS select tsm."MODULE_ID",tsm."MODULE_CODE",tsm."MODULE_NAME",tsm."PARENT_MODULE_ID",tsm."MODULE_TYPE",tsm."SORT_NO",tsm."STATE",tsm."DESCR",tsm."CREATOR_ID",tsm."CREATE_TIME",tsm."MODIFIER_ID",tsm."UPDATE_TIME",tsm."PROJECT_TYPE",tsm."ENG_NAME",tsm."NODE_STATE",tsm."ENTITY_TABLE_NAME",tsm."SHORT_NAME",tsm."FULL_PATH",tsm."PACKAGE_TYPE",tsm."PROJECT_ID",tsm."NODE_TYPE",sys_connect_by_path(tsm.module_id,'/') PARENT_MODULE_IDS,
sys_connect_by_path(REPLACE(tsm.module_name, '/', ''),'/') MODULE_NAME_FULL_PATH
 from top_sys_module tsm
start with tsm.parent_module_id = '-1'
connect by prior tsm.module_id = tsm.parent_module_id
/
