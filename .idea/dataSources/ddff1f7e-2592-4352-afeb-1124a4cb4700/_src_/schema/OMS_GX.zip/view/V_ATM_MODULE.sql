CREATE VIEW V_ATM_MODULE AS WITH t_module AS (
  SELECT a.module_id, a.parent_module_id, a.module_name
  FROM top_sys_module a
  WHERE a.module_type IN (2, 3) AND a.state = 1 )
--当前模块的父模块是什么类型
SELECT t_module_parent.module_id, t_module_parent.module_name, t_module_parent.parent_module_id,
       t_module_parent.parent_type, t_module_sys.sys_id, t_module_sys.sys_name
FROM (
         SELECT a.module_id,a.module_name, a.parent_module_id, decode(b.module_type, 1, 1, 2) parent_type
         FROM t_module a INNER JOIN  top_sys_module b ON a.parent_module_id = b.module_id ) t_module_parent
     INNER JOIN (
        --当前模块对应所属系统
        SELECT module_id sys_id, module_name sys_name, source_module_id
        FROM (
           SELECT module_id, module_name, module_type, t_level, source_module_id,
               MIN(t_level) over(PARTITION BY source_module_id) min_level
            FROM ( SELECT b.module_id, b.module_name, b.module_type,
                     LEVEL t_level, substr(sys_connect_by_path(module_id,'/')||'/', 2,
                                    instr(sys_connect_by_path(module_id,'/')||'/','/',1,2) -2 ) source_module_id
              FROM top_sys_module b
              WHERE b.state = 1 AND module_type = 1
              START WITH b.module_id IN (
                  SELECT module_id FROM t_module)
              CONNECT BY PRIOR b.parent_module_id = b.module_id )
        ) WHERE t_level = min_level ) t_module_sys
   ON t_module_parent.module_id = t_module_sys.source_module_id

/
