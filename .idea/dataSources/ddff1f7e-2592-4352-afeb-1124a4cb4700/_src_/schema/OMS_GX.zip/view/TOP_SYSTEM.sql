CREATE VIEW TOP_SYSTEM AS select t.module_id system_id,t.parent_module_id parent_system_id,
  t.module_code system_code,t.module_name system_name,t.descr DESCRIPTION,t.creator_id,'' creator ,t.create_time
  ,t.modifier_id update_user_id,'' update_user_name,t.update_time ,0 optimistic_lock_version
    from top_sys_module t WHERE t.module_type='1'
/
