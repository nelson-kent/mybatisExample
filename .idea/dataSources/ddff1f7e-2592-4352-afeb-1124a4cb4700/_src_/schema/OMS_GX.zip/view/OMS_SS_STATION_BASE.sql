CREATE VIEW OMS_SS_STATION_BASE AS SELECT fl.FL_ID "UUID",fl.FL_ID "STATION_ID",fl.FL_NAME "STATION_NAME",fl.FL_CODE "STATION_CODE" FROM odcdev_gx.v_oms_dm_function_location@odc_query fl where fl.classify_id = 2
AND  fl.RUNNING_STATE  =1
/
