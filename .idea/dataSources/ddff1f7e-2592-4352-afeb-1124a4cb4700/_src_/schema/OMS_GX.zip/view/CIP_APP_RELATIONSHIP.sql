CREATE VIEW CIP_APP_RELATIONSHIP AS select distinct source_entity.package_id source_module_id,
       target_entity.package_id target_module_id
  from cip_entity_relationship cer,
       cip_entity              source_entity,
       cip_entity              target_entity
 where source_entity.entity_id = cer.source_entity_id
   and target_entity.entity_id = cer.target_entity_id
   and source_entity.package_id != target_entity.package_id
/
