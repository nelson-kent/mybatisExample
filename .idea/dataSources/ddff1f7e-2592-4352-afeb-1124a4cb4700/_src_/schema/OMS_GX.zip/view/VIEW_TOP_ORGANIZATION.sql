CREATE VIEW VIEW_TOP_ORGANIZATION AS select tor.organid  org_id,
       tor.organname org_name,
       tor.ORGANCODE org_code,
       to_number(tor.organgrade) org_type,
       'A' org_structure_id,
       decode(tor.parentid,'','-1',tor.parentid) parent_org_id,
       tmp.full_name_path  name_full_path,
       to_number(tmp.org_level) org_level,
        1   state,
        1  org_property,
       'NULL' short_spell,
       'NULL' full_spell,
       to_number(tor.seq)  sort_no,
       0 area_id,
       tor.emailaddress email_address,
       'NULL'  child_control_area,
       'NULL' flow_area,
       'NULL'  org_duty,
        'NULL' note,
        'SuperAdmin' creator_id,
        sysdate  create_time,
        'SuperAdmin' modifier_id,
        sysdate  update_time,
        'NULL' SAP_HR_ORGID,
    'NULL' BASE_ORG_CODE,
    tor.fourakey fourakey
 from t_tbp_organ tor,
    ( SELECT tto.organid, SUBSTR(REPLACE(SYS_CONNECT_BY_PATH(tto.organname, '@')，'@'，'/') ,2) full_name_path,level  org_level
          FROM t_tbp_organ tto
          START WITH tto.parentid is null
          CONNECT BY PRIOR tto.organid = tto.parentid )  tmp
     where tor.organid=tmp.organid
/
