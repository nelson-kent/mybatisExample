CREATE VIEW CIP_SOA_SERVICE_OBJECT AS select t."SERVICE_ID",t."ENG_NAME",t."CH_NAME",t."SERVICE_ALIAS",t."BUILD_CLASS",t."DESCRIPTION",t."PACKAGE_ID",t."ENTITY_ID"
  from cap_bm_service_object t
 where t.entity_id is null

union

select cso.service_id,
       ce.eng_name,
       ce.ch_name,
       cso.service_alias,
       cso.build_class,
       ce.description,
       cso.package_id,
       cso.entity_id
  from cap_bm_service_object cso, cip_entity ce
 where cso.entity_id = ce.entity_id
/
