CREATE VIEW V_APP_CLASSIFY AS SELECT module_id, module_name, module_code, source_module_id
FROM (
SELECT module_id, module_name, module_type, t_level, source_module_id, module_code,
       MIN(t_level) over(PARTITION BY source_module_id) min_level
    FROM
    ( SELECT b.module_id, b.module_name, b.module_type, b.module_code,
             LEVEL t_level, substr(sys_connect_by_path(module_id,'/')||'/', 2,
                            instr(sys_connect_by_path(module_id,'/')||'/','/',1,2) -2 ) source_module_id
      FROM top_sys_module b
      WHERE b.state = 1
            AND module_type = 3
      START WITH b.module_id IN (
          SELECT a.parent_func_id
          FROM top_per_func a
          WHERE a.status = 1 AND a.func_node_type = 3 )
      CONNECT BY PRIOR b.parent_module_id = b.module_id
    )
)
WHERE t_level = min_level
/
