CREATE VIEW PUB_ROLE_USER AS SELECT a.user_id, b.role_id,  0 CAN_BE_ASSIGN, 0 CAN_BE_EXECUTE, '' ASSIGN_USER_ID, '' IRDS_CODE
    FROM top_user_post_relation a INNER JOIN top_per_subject_role b
         ON a.post_id = b.subject_id INNER JOIN top_per_role c
            ON b.role_id = c.role_id INNER JOIN top_per_role_resource d
               ON c.role_id = d.role_id
    WHERE c.role_state = 1 AND d.access_mode = 1
          AND b.subject_classify_code = 'POST'
/
