CREATE VIEW V_SUBJECT_PERMISSION AS SELECT a.user_id subject_id, 'USER' subject_classify_code, d.resource_id, d.resource_type_code
    FROM top_user_post_relation a INNER JOIN top_per_subject_role b
         ON a.post_id = b.subject_id INNER JOIN top_per_role c
            ON b.role_id = c.role_id INNER JOIN top_per_role_resource d
               ON c.role_id = d.role_id
    WHERE c.role_state = 1 AND d.access_mode = 1
          AND b.subject_classify_code = 'POST'
/
