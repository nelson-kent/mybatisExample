CREATE VIEW TOP_MODULE AS WITH T_MODULE AS
 (SELECT A.MODULE_ID,
         A.PARENT_MODULE_ID,
         A.MODULE_NAME,
         A.MODULE_CODE,
         A.DESCR,
         A.CREATOR_ID,
         A.CREATE_TIME,
         A.MODIFIER_ID,
         A.UPDATE_TIME
    FROM TOP_SYS_MODULE A
   WHERE A.MODULE_TYPE IN ('2', '3'))
--当前模块的父模块是什么类型
SELECT T_MODULE_PARENT.MODULE_ID,
       T_MODULE_PARENT.MODULE_NAME,
       T_MODULE_PARENT.MODULE_CODE,
       T_MODULE_PARENT.DESCR Description,
       DECODE(T_MODULE_PARENT.PARENT_TYPE,1,NULL,T_MODULE_PARENT.PARENT_MODULE_ID) PARENT_MODULE_ID,
        -- T_MODULE_PARENT.PARENT_TYPE,
       T_MODULE_SYS.SYS_ID SYSTEM_ID,
      --T_MODULE_PARENT.PARENT_MODULE_ID bak,
       T_MODULE_PARENT.CREATOR_ID,
       T_MODULE_PARENT.CREATE_TIME,
       T_MODULE_PARENT.MODIFIER_ID UPDATE_USER_ID,
       T_MODULE_PARENT.UPDATE_TIME,
       '' CREATOR,
       '' UPDATE_USER_NAME,
       0 OPTIMISTIC_LOCK_VERSION
  FROM (SELECT A.MODULE_ID,
               A.MODULE_NAME,
               A.PARENT_MODULE_ID,
               DECODE(B.MODULE_TYPE, '1', 1, 2) PARENT_TYPE,
               A.MODULE_CODE,
               A.DESCR,
               A.CREATOR_ID,
               A.CREATE_TIME,
               A.MODIFIER_ID,
               A.UPDATE_TIME
          FROM T_MODULE A
         INNER JOIN TOP_SYS_MODULE B
            ON A.PARENT_MODULE_ID = B.MODULE_ID) T_MODULE_PARENT
 INNER JOIN (
             --当前模块对应所属系统
             SELECT MODULE_ID SYS_ID, SOURCE_MODULE_ID
               FROM (SELECT MODULE_ID,
                             MODULE_TYPE,
                             T_LEVEL,
                             SOURCE_MODULE_ID,
                             MIN(T_LEVEL) OVER(PARTITION BY SOURCE_MODULE_ID) MIN_LEVEL
                        FROM (SELECT B.MODULE_ID,
                                     B.MODULE_NAME,
                                     B.MODULE_TYPE,
                                     LEVEL T_LEVEL,
                                     SUBSTR(SYS_CONNECT_BY_PATH(MODULE_ID, '/') || '/',
                                            2,
                                            INSTR(SYS_CONNECT_BY_PATH(MODULE_ID,
                                                                      '/') || '/',
                                                  '/',
                                                  1,
                                                  2) - 2) SOURCE_MODULE_ID
                                FROM TOP_SYS_MODULE B
                               WHERE MODULE_TYPE = '1'
                               START WITH B.MODULE_ID IN
                                          (SELECT MODULE_ID FROM T_MODULE)
                              CONNECT BY PRIOR B.PARENT_MODULE_ID = B.MODULE_ID))
              WHERE T_LEVEL = MIN_LEVEL) T_MODULE_SYS
    ON T_MODULE_PARENT.MODULE_ID = T_MODULE_SYS.SOURCE_MODULE_ID

/
