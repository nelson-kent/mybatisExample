CREATE PROCEDURE PRO_CREATE_TABLE_COMMENT(SUFFIX_FLAG varchar2) AUTHID CURRENT_USER is

/******************************************************************************
   NAME:       PRO_CREATE_TABLE_COMMENT
   PURPOSE:    用户分表的处理，分表后的新表增加表注释

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2013-8-21    殷海娟        Created this procedure.
******************************************************************************/
BEGIN
	Pro_commentTable_redef('BPMS_RU_CC_TASK',SUFFIX_FLAG);
	Pro_commentTable_redef('BPMS_RU_DONE_TASK',SUFFIX_FLAG);
	Pro_commentTable_redef('BPMS_RU_NODE_TRACK',SUFFIX_FLAG);
	Pro_commentTable_redef('BPMS_RU_PROCESS_INS',SUFFIX_FLAG);
	Pro_commentTable_redef('BPMS_RU_TODO_TASK',SUFFIX_FLAG);
	Pro_commentTable_redef('BPMS_RU_VAR',SUFFIX_FLAG);
	Pro_commentTable_redef('BPMS_RU_ACTIVE_INS',SUFFIX_FLAG);
	Pro_commentTable_redef('BPMS_RU_NODE_ORBIT',SUFFIX_FLAG);
	Pro_commentTable_redef('BPMS_RU_TRANS_TRACK',SUFFIX_FLAG);
	Pro_commentTable_redef('BPMS_RU_NODE_INS',SUFFIX_FLAG);
	Pro_commentTable_redef('BPMS_RU_ATTACHMENT',SUFFIX_FLAG);
	Pro_commentTable_redef('BPMS_RU_REVOKE_LOG',SUFFIX_FLAG);
	Pro_commentTable_redef('BPMS_RU_COMPEVENT_INS',SUFFIX_FLAG);
	Pro_commentTable_redef('BPMS_RU_COMPEVENT_SUS',SUFFIX_FLAG);
	Pro_commentTable_redef('BPMS_RU_MESEVENT_SUS',SUFFIX_FLAG);
	Pro_commentTable_redef('BPMS_RU_MESEVENT_TRI',SUFFIX_FLAG);
	Pro_commentTable_redef('BPMS_RU_SIGEVENT_TRI',SUFFIX_FLAG);
	Pro_commentTable_redef('BPMS_RU_SIGNEVENT_SUS',SUFFIX_FLAG);

END PRO_CREATE_TABLE_COMMENT;

/
