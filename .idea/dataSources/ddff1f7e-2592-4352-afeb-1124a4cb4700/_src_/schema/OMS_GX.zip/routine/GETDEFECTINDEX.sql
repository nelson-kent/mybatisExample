CREATE FUNCTION getDefectIndex (defectIndex in varchar2) return varchar2
   as
defectnum integer;
begin
if defectIndex = '0' or defectIndex = '1' or defectIndex = '2' then defectnum := 100;
elsif defectIndex = '3' then defectnum := 50;
elsif defectIndex = '4' then defectnum := 30;
elsif defectIndex = '5' then defectnum := 20;
end if;
return defectnum;
end;

/
