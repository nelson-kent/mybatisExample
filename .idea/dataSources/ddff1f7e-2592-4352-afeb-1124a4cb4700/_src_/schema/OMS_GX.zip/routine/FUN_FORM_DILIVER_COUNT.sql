CREATE FUNCTION fun_form_diliver_count(orgCode       in varchar2,
                                                   flowName      in varchar2,
                                                   tableName     in varchar2,
                                                   beginTim      in varchar2,
                                                   endTIime      in varchar2,
                                                   condition in varchar2)
  RETURN NUMBER IS
  sumCount number;
  sumStr   varchar2(1000);
   p_sqlerrm VARCHAR2(1000);
BEGIN
   if tableName is null then
     return 0;
   end if;
   if flowName is null then
     return 0;
   end if;
    sumStr := 'select count(*) from ' || tableName ||
              ' where flow_state = 1
  and exists(select max(ru.create_time) from bpms_ru_done_task ru where process_ins_id = ru.main_process_ins_id
                    having  max(ru.create_time)> to_date(''' ||
              beginTim ||
              ''',''yyyy-MM-dd HH24:mi:ss'')
                            and max(ru.create_time)<= to_date(''' ||
              endTIime ||
              ''',''yyyy-MM-dd HH24:mi:ss''))
   and exists(select 1 from bpms_ru_done_task ru ,top_user use ,top_organization org  where process_ins_id = ru.main_process_ins_id
                    and ru.TRANS_ACTOR_ID = use.EMPLOYEE_ID and use.ORG_ID = org.org_id
					and ru.status = 1
          and org.org_code like ''' || orgCode || '%''
       )';
  if condition is not null  then
      sumStr := sumStr || ' and '||condition;
  end if;

  EXECUTE IMMEDIATE sumStr
    INTO sumCount;
  if tableName = 'OMS_SS_BASEBUILDENTER' then
    sumCount := sumCount * 3;
  end if;
  return nvl(sumCount,0);
  exception when others then
     p_sqlerrm := tableName||'表查询异常'||sqlerrm; --错误信息显示
     insert into PRO_FUN_RUN_LOG
      (p_name, p_date, p_time, p_sqlerrm, p_error)
    values
      ('fun_form_diliver_count', --存储过程名称
       sysdate, --数据日期
       to_char(sysdate, 'YYYY-MM-DD HH:MI:SS'), --跑批时间
       p_sqlerrm, --错误信息
       dbms_utility.format_error_backtrace() --错误位置
       );
    commit;
    return 0;
END fun_form_diliver_count;

/
