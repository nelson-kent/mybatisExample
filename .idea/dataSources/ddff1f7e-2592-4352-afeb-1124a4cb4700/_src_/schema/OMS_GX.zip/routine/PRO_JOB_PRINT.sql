CREATE procedure pro_job_print
as
   begin
       --dbms_output.put_line('系统时间：' || to_char(sysdate, 'dd-mm-yyyy hh24:mi:ss'));
       insert into tab_time values(sysdate);
   end;
/
