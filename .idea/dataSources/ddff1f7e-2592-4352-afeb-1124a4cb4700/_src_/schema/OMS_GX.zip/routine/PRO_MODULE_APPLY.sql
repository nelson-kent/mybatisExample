CREATE PROCEDURE PRO_MODULE_APPLY
is
cursor tableNameCur is select  modu.table_name,modu.module_name,modu.flow_name,modu.business_name,
   modu.principal_name,modu.unit_name,modu.major_name
      from OMS_MODULE_APPLY modu;
tableName  OMS_MODULE_APPLY.table_name%type;
moduleName oms_module_apply.module_name%type;
flowName  OMS_MODULE_APPLY.Flow_Name%type;
businessName oms_module_apply.business_name%type;
principalName  OMS_MODULE_APPLY.PRINCIPAL_NAME%type;
unitName oms_module_apply.unit_name%type;
majorName  OMS_MODULE_APPLY.Major_Name%type;
version OMS_MODULE_STATISTICS_MANAGE.Version%type; -- 最大版本
omsmCount number;--模块统计数
joinStr varchar2(3000);
beginTime  varchar2(100); -- 开始时间
endTime   varchar2(100);--结束时间
sumStr varchar2(3000);
zdSunCount number; -- 中调总计数
zdPeriodCount number; -- 中调现在计数
sunCount number;
peroidCount number;
TYPE emp_ssn_array IS TABLE OF NUMBER
INDEX BY BINARY_INTEGER;
best_employees emp_ssn_array;
begin
   --结束日期
    endTime := to_char(sysdate,'yyyy-MM-dd HH24:mi:ss');
   -- 得到最大版本号
   select count(*) into omsmCount from OMS_MODULE_STATISTICS_MANAGE;
   if omsmCount > 0 then
     select max(version) into version from OMS_MODULE_STATISTICS_MANAGE;
   else
     version := 0;
   end if;
open tableNameCur;
loop
fetch tableNameCur into tableName,moduleName,flowName,businessName,principalName,unitName,majorName;
exit when tableNameCur%notfound;
if tableNameCur%found then
    -- 判断单前模块之前是否被统计，如果被统计则查询出上次统计次数以及结束时间，如果没有统计，则认为上次统计为0，结束时间为上周的今天
     if omsmCount >0 then
        joinStr := 'select count(*) from  OMS_MODULE_STATISTICS_MANAGE where    Module_Name ='''||moduleName||'''and  Version ='||version;
         EXECUTE IMMEDIATE joinStr INTO  omsmCount;
     end if;
     if omsmCount >0 then
         joinStr := 'select  to_char(Count_End_Time,''yyyy-MM-dd HH24:mi:ss'') from  OMS_MODULE_STATISTICS_MANAGE where    Module_Name ='''||moduleName||'''and  Version ='||version;
         EXECUTE IMMEDIATE joinStr INTO  beginTime;
     else
      beginTime := to_char(sysdate-7,'yyyy-MM-dd HH24:mi:ss');
     end if;

    -- 清空
       sumStr :=' ';
       sunCount := 0;
       peroidCount := 0;

      -- 南宁
       best_employees(1) := fun_get_module_count('0401',flowName,tableName,beginTime,endTime);
       best_employees(2) := fun_get_module_sum_count('nl_sum_count',best_employees(1),omsmCount,version,moduleName);
       -- 柳州
       best_employees(3) := fun_get_module_count('0402',flowName,tableName,beginTime,endTime);
       best_employees(4) := fun_get_module_sum_count('lz_sum_count',best_employees(3),omsmCount,version,moduleName);
        -- 河池
       best_employees(5) := fun_get_module_count('0405',flowName,tableName,beginTime,endTime);
       best_employees(6) :=fun_get_module_sum_count('Ch_Sum_Count',best_employees(5),omsmCount,version,moduleName);
        -- 桂林
       best_employees(7) := fun_get_module_count('0403',flowName,tableName,beginTime,endTime);
       best_employees(8) := fun_get_module_sum_count('Gl_Sum_Count',best_employees(7),omsmCount,version,moduleName);
        -- 梧州
       best_employees(9) := fun_get_module_count('0408',flowName,tableName,beginTime,endTime);
       best_employees(10) := fun_get_module_sum_count('Wz_Sum_Count',best_employees(9),omsmCount,version,moduleName);
        -- 贺州
       best_employees(11) := fun_get_module_count('0414',flowName,tableName,beginTime,endTime);
       best_employees(12) := fun_get_module_sum_count('Hz_Sum_Count',best_employees(11),omsmCount,version,moduleName);
        -- 北海
       best_employees(13) := fun_get_module_count('0409',flowName,tableName,beginTime,endTime);
       best_employees(14) := fun_get_module_sum_count('Bh_Sum_Count',best_employees(13),omsmCount,version,moduleName);
        -- 防城港
       best_employees(15) := fun_get_module_count('0407',flowName,tableName,beginTime,endTime);
       best_employees(16) := fun_get_module_sum_count('Fcg_Sum_Count',best_employees(15),omsmCount,version,moduleName);
        -- 玉林
       best_employees(17) := fun_get_module_count('0404',flowName,tableName,beginTime,endTime);
       best_employees(18) := fun_get_module_sum_count('Yl_Sum_Count',best_employees(17),omsmCount,version,moduleName);
        -- 钦州
       best_employees(19) := fun_get_module_count('0406',flowName,tableName,beginTime,endTime);
       best_employees(20) :=fun_get_module_sum_count('Qz_Sum_Count',best_employees(19),omsmCount,version,moduleName);
        -- 贵港
       best_employees(21) := fun_get_module_count('0410',flowName,tableName,beginTime,endTime);
       best_employees(22) := fun_get_module_sum_count('Gg_Sum_Count',best_employees(21),omsmCount,version,moduleName);
        -- 崇左
       best_employees(23) := fun_get_module_count('0411',flowName,tableName,beginTime,endTime);
       best_employees(24) := fun_get_module_sum_count('Cz_Sum_Count',best_employees(23),omsmCount,version,moduleName);
        -- 来宾
       best_employees(25) := fun_get_module_count('0412',flowName,tableName,beginTime,endTime);
       best_employees(26) :=fun_get_module_sum_count('Lb_Sum_Count',best_employees(25),omsmCount,version,moduleName);
        -- 百色
       best_employees(27) := fun_get_module_count('0413',flowName,tableName,beginTime,endTime);
       best_employees(28) := fun_get_module_sum_count('Bs_Sum_Count',best_employees(27),omsmCount,version,moduleName);
       -- 中调
       zdPeriodCount := fun_get_module_count('0460',flowName,tableName,beginTime,endTime);
       zdSunCount := fun_get_module_sum_count('Zd_Sum_Count',zdPeriodCount,omsmCount,version,moduleName);
       --地调统计总共
       FOR i IN 1..best_employees.count LOOP
            if mod(i,2) = 0 then
               sunCount := sunCount+ best_employees(i);
            else
              peroidCount := peroidCount+ best_employees(i);
            end if;
        END LOOP;
      insert into OMS_MODULE_STATISTICS_MANAGE (
         Uuid ,
         CREATE_TIME ,
         TABLE_NAME,
         Flow_Name,
         Business_Name,
         Principal_Name,
         Module_Name,
         Major_Name,
         Unit_Name,
         Nl_Period_Count,
         Nl_Sum_Count,
         Lz_Period_Count,
         Lz_Sum_Count,
         Ch_Period_Count,
         Ch_Sum_Count,
         Gl_Period_Count,
         Gl_Sum_Count,
         Wz_Period_Count,
         Wz_Sum_Count,
         Hz_Period_Count,
         Hz_Sum_Count,
         Bh_Period_Count,
         Bh_Sum_Count,
         Fcg_Period_Count,
         Fcg_Sum_Count,
         Yl_Period_Count,
         Yl_Sum_Count,
         Qz_Period_Count,
         Qz_Sum_Count,
         Gg_Period_Count,
         Gg_Sum_Count,
         Cz_Period_Count,
         Cz_Sum_Count,
         Lb_Period_Count,
         Lb_Sum_Count,
         Bs_Period_Count,
         Bs_Sum_Count,
         Dd_Period_Count,
         Dd_Sum_Count,
         Zd_Period_Count,
         Zd_Sum_Count,
         Count_Start_Time,
         Count_End_Time,
         Version
      )values(
         sys_guid(),
         sysdate,
         tableName,
         flowName,
         businessName,
         principalName,
         moduleName,
         majorName,
         unitName,
         best_employees(1),
         best_employees(2),
         best_employees(3),
         best_employees(4),
         best_employees(5),
         best_employees(6),
         best_employees(7),
         best_employees(8),
         best_employees(9),
         best_employees(10),
         best_employees(11),
         best_employees(12),
         best_employees(13),
         best_employees(14),
         best_employees(15),
         best_employees(16),
         best_employees(17),
         best_employees(18),
         best_employees(19),
         best_employees(20),
         best_employees(21),
         best_employees(22),
         best_employees(23),
         best_employees(24),
         best_employees(25),
         best_employees(26),
         best_employees(27),
         best_employees(28),
         peroidCount,
         sunCount,
         zdPeriodCount,
         zdSunCount,
         to_date(beginTime,'yyyy-MM-dd HH24:mi:ss'),
         to_date(endTime,'yyyy-MM-dd HH24:mi:ss'),
         version+1
      );
end if;
end loop;
close tableNameCur;
end PRO_MODULE_APPLY;
/
