CREATE FUNCTION check_edit(mission_id in varchar2) 
RETURN mission_result is
                                       mission_result  boolean;
                                       begin
                                         if mission_id > '' then
                                            return true;
                                         end if;
                                             return type_array;

                                         --return mission_result;
                                       end check_edit;
/
