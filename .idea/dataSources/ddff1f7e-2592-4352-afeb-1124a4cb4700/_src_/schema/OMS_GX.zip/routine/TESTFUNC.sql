CREATE FUNCTION testFunc (num1 IN NUMBER, num2 IN NUMBER)
RETURN NUMBER
AS
    num3 number;
    num4 number;
    num5 number;
BEGIN
    num3 := num1 + num2;
    num4 := num1 * num2;
    num5 := num3 * num4;
    RETURN num5;
END;
/
