CREATE procedure pro_visit_menudata(c_date varchar2) AUTHID CURRENT_USER is
  v_cnt NUMBER(10);
  t_count      NUMBER(10);
  t_statisticstime date;
  starttime date;
  endtime   date;
  /*****************************************************************************
        DATE：2013.11.15
        purpose：获得每个用户在一段时间内的菜单单击次数。

  *******************************************************************************/
begin
  starttime := to_date(c_date, 'yyyy-MM-dd  HH24:mi:ss');
  --结束时间等于开始时间+1天
  endtime := starttime + 1;
  t_statisticstime := to_date(c_date, 'yyyy-mm-dd');



  select count(1) into v_cnt from user_tables where table_name = 'PID_MENU_STATISTICS';
  IF v_cnt = 0 THEN
        --创建会话级临时表，主要用来存储待处理的父节点ID数据、父节点名称，以及每次需要更新的登录次数、总数
        EXECUTE IMMEDIATE 'create global temporary table PID_MENU_STATISTICS(pid varchar2(32),
                                             org_name varchar2(128),
                                             MENU_ID VARCHAR2(32),
                                             MENU_NAME varchar2(128),
                                             click_count number(10)) on commit Preserve  rows';
  ELSE
       EXECUTE IMMEDIATE 'truncate table PID_MENU_STATISTICS';
  END IF;

  select count(1) into v_cnt from user_tables where table_name = 'PID_MENU_STATISTICS_BEATA';
  IF v_cnt = 0 THEN
        --创建会话级临时表，主要用来存储待处理的父节点ID数据、父节点名称，以及每次需要更新的登录次数、总数
        EXECUTE IMMEDIATE 'create global temporary table PID_MENU_STATISTICS_BEATA(pid varchar2(32),
                                             org_name varchar2(128),
                                             MENU_ID VARCHAR2(32),
                                             MENU_NAME varchar2(128),
                                             click_count number(10)) on commit Preserve  rows';
  ELSE
       EXECUTE IMMEDIATE 'truncate table PID_MENU_STATISTICS_BEATA';
  END IF;

  --先删除表中今天统计的菜单点击次数，防止重复插入
  DELETE FROM top_function_use WHERE STATISTICS_TIME = t_statisticstime;
   --将指定时间下每个菜单的点击次数放入统计表中
  INSERT INTO top_function_use(FUN_USE_ID,STATISTICS_TIME, FUN_ID,FUN_NAME,ORG_ID, ORG_NAME, CLICK_COUNT)
  SELECT sys_guid(),t_statisticstime,fun_id,fun_name,ORG_ID,ORG_NAME, SUM(b.fun_oper_num) AS click_count
  FROM (select *
        from top_log_user_operate
        where OPERATE_TYPE = 2
  ) a,top_log_fun_detail b
  WHERE a.operate_id = b.operate_id
  AND b.FUN_OPER_DATE < endtime
  AND b.FUN_OPER_DATE >= starttime
  GROUP BY b.fun_id,b.fun_name,a.org_id,a.org_name
  HAVING  SUM(b.fun_oper_num) > 0;

  --将指定时间下每个菜单的点击次数放入临时表中
  EXECUTE IMMEDIATE 'INSERT INTO PID_MENU_STATISTICS(pid, org_name,MENU_ID,MENU_NAME, click_count)
                    SELECT  t1.org_id , t1.org_name,t2.fun_id,t2.fun_name, t2.t_login_count
                    FROM  top_organization t1 inner join
                          ( select  b.PARENT_ORG_ID, c.fun_id,c.fun_name,sum(c.CLICK_COUNT) as t_login_count
                            FROM  top_function_use c
                                  inner join top_organization b
                             ON c.ORG_ID = b.org_ID
                             where  c.statistics_time = to_date('''||c_date||''', ''yyyy-mm-dd'')
                              AND b.PARENT_ORG_ID <> ''-1''
                              group by b.PARENT_ORG_ID, c.fun_id,c.fun_name
                            )  t2 on t1.org_id = t2.PARENT_ORG_ID';

  --更新top_function_use表
   EXECUTE IMMEDIATE 'select count(1) from PID_MENU_STATISTICS' INTO t_count;
   WHILE t_count > 0  LOOP
     BEGIN
         EXECUTE IMMEDIATE 'MERGE INTO top_function_use a
         USING (SELECT p1.pid, p1.org_name, p1.MENU_ID,p1.MENU_NAME,click_count AS t_login_count
                       FROM PID_MENU_STATISTICS p1
                ) b  ON (a.org_id = b.pid and b.menu_id = a.fun_id and
                  a.statistics_time =  to_date('''||c_date||''', ''yyyy-mm-dd''))
           WHEN MATCHED THEN
                UPDATE SET a.click_count = a.click_count + b.t_login_count
           WHEN NOT MATCHED THEN
                INSERT(FUN_USE_ID,STATISTICS_TIME, ORG_ID, ORG_NAME, fun_ID,fun_NAME,click_count)
                VALUES(sys_guid(),to_date('''||c_date||''', ''yyyy-mm-dd''), b.pid, b.org_name,b.menu_id,b.menu_name, b.t_login_count)';

          EXECUTE IMMEDIATE 'truncate table PID_MENU_STATISTICS_BEATA';
          EXECUTE IMMEDIATE 'insert into PID_MENU_STATISTICS_BEATA(pid, org_name, menu_id,menu_name,click_count)
                     SELECT  t1.org_id , t1.name, t2.menu_id,t2.menu_name,t2.t_login_count
                     FROM  top_organization t1 inner join
                          ( select  b.PARENT_ORG_ID, c.menu_id,c.menu_name,sum(c.CLICK_COUNT) as t_login_count
                            FROM  PID_MENU_STATISTICS c
                                  inner join top_organization b
                             ON c.pid = b.ORG_ID
                             where b.PARENT_ORG_ID <> ''-1''
                              group by b.PARENT_ORG_ID,c.menu_id,c.menu_name
                            )  t2 on t1.org_id = t2.PARENT_ORG_ID';
           EXECUTE IMMEDIATE 'truncate table PID_MENU_STATISTICS';
           EXECUTE IMMEDIATE 'insert into PID_MENU_STATISTICS select * from PID_MENU_STATISTICS_BEATA';
           EXECUTE IMMEDIATE 'select count(1) from PID_MENU_STATISTICS ' INTO t_count;

     END;
   END LOOP;

   commit;

   --将临时表干掉，会话级临时表需要truncate 之后才能干掉
  EXECUTE IMMEDIATE 'truncate table PID_MENU_STATISTICS';
  EXECUTE IMMEDIATE 'drop table PID_MENU_STATISTICS';
  EXECUTE IMMEDIATE 'truncate table PID_MENU_STATISTICS_BEATA';
  EXECUTE IMMEDIATE 'drop table PID_MENU_STATISTICS_BEATA';

end pro_visit_menudata;

/
