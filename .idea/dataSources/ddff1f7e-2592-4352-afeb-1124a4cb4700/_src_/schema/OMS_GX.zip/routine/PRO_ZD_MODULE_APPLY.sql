CREATE PROCEDURE PRO_ZD_MODULE_APPLY(beginTime varchar2,
                                                    endTime   varchar2) is
  cursor tableNameCur is
    select dic.moduleid,
           dic.flowname,
           dic.tablename,
           dic.majordistinguishcondition
      from T_TBP_COUNT_DIC dic
     where dic.factory = '康拓普'and type = '1';
  moduleId      T_TBP_COUNT_DIC.moduleid%type;
  flowName      T_TBP_COUNT_DIC.Flowname%type;
  tableName     T_TBP_COUNT_DIC.Tablename%type;
  majorCondtion T_TBP_COUNT_DIC.majordistinguishcondition%type;

  recordTime date;
  zdPeriodCount number; -- 中调现在计数
begin
  recordTime := sysdate;
  open tableNameCur;
  loop
    fetch tableNameCur
      into moduleId, flowName, tableName, majorCondtion;
    exit when tableNameCur%notfound;
    if tableNameCur%found then
      -- 中调
      zdPeriodCount := fun_comtop_module_count('0460',
                                               flowName,
                                               tableName,
                                               beginTime,
                                               endTime,
                                               majorCondtion);
      --中调新增数
      insert into T_TBP_COUNT_ZDBUSI
        (RECORDID, NEWBUSINUM, RECORDTIME, MODULEID)
      values
        (sys_guid(), zdPeriodCount, recordTime, moduleId);
    end if;
  end loop;
  close tableNameCur;
end PRO_ZD_MODULE_APPLY;
/
