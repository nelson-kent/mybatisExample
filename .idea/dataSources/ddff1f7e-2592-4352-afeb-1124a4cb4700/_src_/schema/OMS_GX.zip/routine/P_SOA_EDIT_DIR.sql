CREATE PROCEDURE P_SOA_EDIT_DIR (dirCode varchar2,dirName varchar2,dirMemo varchar2)IS
dataCount NUMBER;-- 统计数据
oldFullPath varchar2(2000); --服务目录全路径
newfullPath varchar2(2000); --服务目录全路径
/******************************************************************************
   NAME:       P_SOA_EDIT_DIR
   PURPOSE:    修改服务目录时对子目录的全路径修改存储过程
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2014-3-10    lixiaoqiang      1. Created this procedure.
******************************************************************************/
BEGIN

 select count(1)  into dataCount from soa_dir where dir_code=dirCode;

 --只有在指定的目录编号存在时才做修改操作
 if dataCount>0 then

 --先记录修改前的服务全目录
  select dir_full_path into oldFullPath from soa_dir where dir_code=dirCode;

  --算出新的服务全目录--上级的全目录+/+dirName
  select substr(oldFullPath,0,INSTR(oldFullPath,'/', -1, 1)) ||dirName into newfullPath  from dual;

  --得到所有的子目录
  for childs in(SELECT dir_code,dir_full_path FROM SOA_DIR sd CONNECT BY PRIOR sd.DIR_CODE=sd.PARENT_DIR_CODE START WITH sd.DIR_CODE=dirCode) loop
    --修改子目录全路径
    update SOA_DIR set dir_full_path = newfullPath||substr(dir_full_path,length(oldFullPath)+1)  where DIR_CODE=childs.dir_code;
  end loop;
  --修改名称、备注
   update SOA_DIR set dir_memo = dirMemo ,dir_name =dirName where dir_code=dirCode;
 commit;
 end if;

END P_SOA_EDIT_DIR;

/
