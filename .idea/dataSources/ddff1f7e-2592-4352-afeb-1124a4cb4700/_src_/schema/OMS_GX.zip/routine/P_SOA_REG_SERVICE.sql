CREATE PROCEDURE P_SOA_REG_SERVICE(
serviceCode varchar2,serviceName varchar2,dirPath varchar2,
builderCalss VARCHAR2,fileName  VARCHAR2,serviceAddress VARCHAR2) IS

dirCode varchar2(40);--服务目录编号
countNum number(1);--统计数据
/******************************************************************************
   NAME:       P_SOA_REG_SERVICE
   PURPOSE:  注册服务类、服务目录数据的储存过程，负责：服务类SOA_SERVICE、SOA_DIR数据
   每个服务类中对应的服务目录编号，通过将DIR_PATH,插入或查询出对应服务目录编号，与之关联
   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2014-2-10    lixiaoqiang   Created this procedure.
******************************************************************************/
BEGIN
--第一步查询数据库中是否有此
   select count(1) into countNum from soa_dir where dir_full_path=dirPath ;
-- 第二步：处理服务目录数据，得到服务目录编号
    if countNum=0 then
        --调用服务目录处理存储过程
        P_SOA_REG_DIR(dirPath);
    end if;
   select count(1) into countNum from soa_dir where dir_full_path=dirPath;
 -- 第四步：处理服务目录编号,如果仍然为空。则dirCode=''
    if countNum=0 then
       dirCode:='';
    end if;
    if countNum>0 then
        select DIR_CODE into dirCode from soa_dir where dir_full_path=dirPath;
    end if;
--第五步：插入注册服务类表数据
    select count(1) into countNum from SOA_SERVICE where SERVICE_CODE=serviceCode ;
    if countNum>0 then
        --删除服务类信息
        delete SOA_SERVICE where SERVICE_CODE=serviceCode;
        --------------------下面是临时删除----------------
      --删除参数对应信息
    --  delete SOA_PARAM_DETAIL det where det.PARAM_CODE in(
       -- select para.PARAM_CODE from SOA_PARAM para where para.METHOD_CODE in(
       --   SELECT met.METHOD_CODE FROM SOA_METHOD met where met.SERVICE_CODE = serviceCode ));

       --删除服务类所对应的参数信息
      --delete SOA_PARAM where METHOD_CODE in(SELECT met.METHOD_CODE FROM SOA_METHOD met where met.SERVICE_CODE = serviceCode);
        --删除服务类所关联的服务方法
     -- delete SOA_METHOD where SERVICE_CODE = serviceCode;
    end if;
    insert into SOA_SERVICE(SERVICE_CODE,SERVICE_NAME,DIR_CODE,BUILDER_CLASS,REGISTER_FILE_NAME,SERVICE_ADDRESS)
                        values (serviceCode,serviceName,dirCode,builderCalss,fileName,serviceAddress);
END P_SOA_REG_SERVICE;

/
