CREATE function dbo
(@m_str varchar(80))
returns varchar(80)
 as begin
    declare @i varchar(80)
    if @m_str='0'
       set @i='A'


    if @m_str='1'
       set @i='B'
    return (@i)
end
  /
