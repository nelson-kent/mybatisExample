CREATE procedure PRO_INITREALPOSTBYREALCODE(realCode varchar2) is
/**************************************************************************************************************
    purpose:根据实际岗位ID，获取所属的标准岗位的角色权限，再复制给实际岗位
            处理逻辑：先删除实际岗位关联的所有权限信息，再根据标准岗位的权限初始化。
    param:realCode 实际岗位ID，可放置多个值，以英文逗号隔开，例如 ZH_ZC,ZH_WZ
**************************************************************************************************************/
    arr_codes type_array := type_array();
    v_real_code VARCHAR2(200);
    v_stand_code VARCHAR2(200);
BEGIN
     arr_codes := f_split(realCode, ',');
     IF arr_codes.COUNT > 0 THEN
        FOR i IN arr_codes.FIRST .. arr_codes.LAST
        LOOP
            v_real_code := arr_codes(i);
            IF v_real_code IS NOT NULL THEN
               --通过实际岗位ID编码得到标准岗位的ID编码，如标准岗位ID编码不存在，则程序报错。
               BEGIN
                  SELECT b.other_post_id INTO v_stand_code
                  FROM top_post_other b
                  WHERE b.other_post_id = ( SELECT a.standard_post_code FROM top_post a WHERE  a.state=1 and a.post_id = v_real_code );
               EXCEPTION
                   WHEN No_data_found THEN
                        dbms_output.put_line('通过实际岗位ID编码'||v_real_code||'无法找到标准岗位，请检查。');
                   WHEN Too_many_rows THEN
                        dbms_output.put_line('通过实际岗位ID编码'||v_real_code||'可以找到多条标准岗位，请检查数据。');
               END;
               --删除实际岗位下的人员角色权限
               DELETE FROM top_per_subject_role
               WHERE SUBJECT_CLASSIFY_CODE = 'USER'
               AND (subject_id, role_id) IN (
                           SELECT t_user.user_id, t_role.role_id
                           FROM (SELECT b.User_Id
                               FROM top_post a INNER JOIN top_user_post_relation b
                                    ON a.post_id = b.post_id
                               WHERE a.post_id = v_real_code AND a.state = 1 ) t_user,
                               (SELECT b.role_id
                                  FROM top_post a INNER JOIN top_per_subject_role b
                                       ON a.post_id = b.subject_id
                                  WHERE a.post_id = v_real_code AND a.state = 1
                                        AND b.SUBJECT_CLASSIFY_CODE = 'POST') t_role )
                     and role_id in  (
                                      select ps.role_id from top_post_other p,top_per_subject_role ps
                                      where p.other_post_id=ps.subject_id
                                      and p.state=1
                                      and ps.subject_classify_code='POST'
                                      and p.other_post_flag=2
                                      and p.other_post_id=v_stand_code
                            );
               --删除实际岗位与角色的关联
               DELETE FROM top_per_subject_role
                      WHERE SUBJECT_CLASSIFY_CODE = 'POST'
                            AND (role_id, subject_id) IN (
                                SELECT b.role_id, a.post_id
                                FROM top_post a INNER JOIN top_per_subject_role b
                                     ON a.post_id = b.subject_id
                                WHERE a.post_id = v_real_code AND a.state = 1
                                      AND b.SUBJECT_CLASSIFY_CODE = 'POST')
                            and role_id in  (
                                       select ps.role_id from top_post_other p,top_per_subject_role ps
                                      where p.other_post_id=ps.subject_id
                                      and p.state=1
                                      and ps.subject_classify_code='POST'
                                       and p.other_post_flag=2

                                      and p.other_post_id=v_stand_code
                            );
               --新增实际岗位与角色的关联
               INSERT INTO top_per_subject_role(subject_role_id, role_id, subject_id, subject_classify_code,
                      creator_id, create_time)
              SELECT sys_guid(), t_role.role_id, t_post.post_id, 'POST', 'SuperAdmin', SYSDATE
               FROM ( SELECT b.role_id
               FROM top_post_other a INNER JOIN top_per_subject_role b
                    ON a.other_post_id = b.subject_id
               WHERE a.other_post_id = v_stand_code AND a.state = 1  and a.other_post_flag=2
                     AND b.SUBJECT_CLASSIFY_CODE = 'POST') t_role,
                (SELECT c.post_id FROM top_post c
                 WHERE c.post_id = v_real_code AND c.state = 1 ) t_post;

               --新增实际岗位下用户与角色的关联
               INSERT INTO TOP_PER_SUBJECT_ROLE(subject_role_id, role_id, subject_id, Subject_Classify_Code,
                      CREATOR_ID,CREATE_TIME)
                SELECT SYS_GUID(), ROLE_ID, USER_ID, 'USER','SuperAdmin',SYSDATE
                FROM ( SELECT DISTINCT a.role_id, b.user_id
                      FROM top_per_subject_role a INNER JOIN  top_user_post_relation b
                         ON a.subject_id = b.post_id INNER JOIN top_post c ON b.post_id = c.post_id
                      WHERE c.post_id = v_real_code AND a.subject_classify_code = 'POST' AND c.state = 1)
                      where  role_id in (
                                      select ps.role_id from top_post_other p,top_per_subject_role ps
                                      where p.other_post_id=ps.subject_id
                                      and p.state=1
                                      and ps.subject_classify_code='POST'
                                      and p.other_post_flag=2
                                      and p.other_post_id=v_stand_code
                            );
            END IF;
        END LOOP;
     END IF;
     COMMIT;
end PRO_INITREALPOSTBYREALCODE;

/
