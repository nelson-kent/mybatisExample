CREATE function F_GET_LAST_VALUE(STR VARCHAR2,  STR_SEPARATOR VARCHAR2) return varchar2 IS
  arr_strs type_array;
/***************************************************************************
  使用分隔符STR_SEPARATOR对STR进行分割，并返回分割出来的数组中的最后一个值
**************************************************************************/
begin
  arr_strs := f_split(STR, STR_SEPARATOR);
  RETURN arr_strs(arr_strs.LAST);
end F_GET_LAST_VALUE;

/
