CREATE PROCEDURE P_SOA_REG_PARAM_DETAIL(detailCode VARCHAR2,paramCode VARCHAR2,
sourceExp VARCHAR2,paramType VARCHAR2,targetExp VARCHAR2,xmlsType varchar2,defaultValue VARCHAR2) IS
/******************************************************************************
   NAME:       P_SOA_REG_PARAM_DETAIL
   REVISIONS:注册参数关联信息存储过程
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2014-4-8       lixiaoqiang   Created procedure.
******************************************************************************/
BEGIN
--先删除原有的数据
delete SOA_PARAM_DETAIL where PARAM_DETAILL_CODE=detailCode;
--插入新数据
insert into SOA_PARAM_DETAIL (PARAM_DETAILL_CODE,PARAM_CODE,PARAM_SOURCE_EXP,PARAM_Java_TYPE,PARAM_TARGET_EXP,PARAM_DEFAULT_VALUE,PARAM_XML_TYPE)
values(detailCode,paramCode,sourceExp,paramType,targetExp,defaultValue,xmlsType);

END P_SOA_REG_PARAM_DETAIL;

/
