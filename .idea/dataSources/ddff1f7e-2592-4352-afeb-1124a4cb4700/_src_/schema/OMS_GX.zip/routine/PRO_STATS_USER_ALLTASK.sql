CREATE PROCEDURE pro_stats_user_Alltask(userId varchar2, outTaskNum number) IS
/******************************************************************************
   NAME:       pro_stats_user_Alltask
   PURPOSE:     从实时表中进行数据统计

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2012-12-25    李小强      1. 统计用户当前的所有待办任务数
******************************************************************************/

--TYPE process_array IS TABLE OF varchar2(50) INDEX BY BINARY_INTEGER;--定义一个一维数组结构
--suff_tables process_array;--用于存放流程分表后缀的临时数据
tmpVar NUMBER;--统计数据
 exeSQL   varchar2(1000); --要执行SQL语句
BEGIN
   tmpVar := 0;--初始值
   --统计未分表的数据
 select count(1)+tmpVar into tmpVar from BPMS_RU_TODO_TASK where trans_actor_id =userId;
 --将分表的配置查询出来并放入一个临时数据
 --select 'BPMS_RU_TODO_TASK_'||suffix_flag into suff_tables from BPMS_CFG_REDEF_TABLE;
 --FOR i IN 1..suff_tables.count LOOP
 for table_tmp in (select 'BPMS_RU_TODO_TASK_'||suffix_flag as table_name from BPMS_CFG_REDEF_TABLE)
 loop
 exeSQL := 'select count(1)+tmpVar into tmpVar from '||table_tmp.table_name||' where trans_actor_id =' ||userId;
 DBMS_OUTPUT.PUT_LINE('tmpVar:' ||tmpVar);

 execute immediate exeSQL;
end loop;



END pro_stats_user_Alltask;

/
