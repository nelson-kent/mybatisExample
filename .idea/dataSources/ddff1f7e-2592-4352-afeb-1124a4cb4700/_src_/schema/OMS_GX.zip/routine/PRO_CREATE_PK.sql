CREATE PROCEDURE PRO_CREATE_PK(tableName   varchar2,
                                          columnName  varchar2,
                                          code varchar2) AUTHID CURRENT_USER is
  /******************************************************************************
     NAME:       PRO_CREATE_PK_AND_INDEX
     PURPOSE:    给分表创建主键

     REVISIONS:
     Ver        Date        Author           Description
     ---------  ----------  ---------------  ------------------------------------
     1.0        2014-11-20    翟羽佳       Created this procedure.
  ******************************************************************************/
  newTableName    varchar2(40); ---新的表名
  varSql          varchar2(1000); ---动态sql
  existCount      number(4); ---是否存在标示
  preCode         varchar2(40);
  pkName          varchar2(40);

BEGIN
    newTableName := tableName || '_' || code;
    preCode:=substr(newTableName,9,30);
    --创建主键，先查询出原表主键列名，创建主键时先查如果没有再加
    select count(*)
      into existCount
      from user_constraints t
     where t.table_name = upper(newTableName)
       and t.constraint_type = 'P';
    if existCount = 0 then
      --创建主键
      pkName:='pk_'||preCode;
      varSql := 'alter table ' || newTableName || ' add constraint ' ||
                pkName || ' primary key ('||columnName||')';
      execute immediate varSql;
    end if;
END PRO_CREATE_PK;

/
