CREATE PROCEDURE P_soa_delete_service(serviceCode varchar2) AUTHID CURRENT_USER is
PRAGMA AUTONOMOUS_TRANSACTION;

/******************************************************************************
   NAME:       Pro_createTable_NotExist
   PURPOSE:    删除指定的SOA服务（包括南网服务及本地服务）
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2014-8-13      欧阳辉        1. Created this procedure
******************************************************************************/
BEGIN
delete from soa_webservice  w where w.method_code in (select m.method_code from soa_method m  where m.service_code=serviceCode);
delete from soa_param_detail pd where pd.param_code in (select p.param_code from soa_param p where p.method_code in (select m.method_code from soa_method m  where m.service_code=serviceCode));
delete from soa_param p where p.method_code in (select m.method_code from soa_method m  where m.service_code=serviceCode);
delete from soa_method m  where m.service_code=serviceCode;
delete from soa_service s where s.service_code=serviceCode;
delete from SOA_SERVICE_RELATE_DIR r where r.service_code=serviceCode;
commit;
END P_soa_delete_service;

/
