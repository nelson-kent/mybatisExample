CREATE FUNCTION fun_get_module_count_range(flowName  in varchar2,
                                                tableName in varchar2,
                                                beginTim  in varchar2,
                                                endTIime  in varchar2,
                        majorCondtion in varchar2
                        )
  RETURN NUMBER IS
  sumCount number;
  sumStr   varchar2(1000);
BEGIN
  if flowName is null then
    sumStr := 'select count(*) from ' || tableName ||
              ' where create_time>= to_date(''' || beginTim ||
              ''',''yyyy-MM-dd HH24:mi:ss'')
               and create_time<= to_date(''' || endTIime ||
              ''',''yyyy-MM-dd HH24:mi:ss'')';
  else
    sumStr := 'select count(*) from ' || tableName ||
              ' where flow_state = 2
                     and exists(select max(ru.create_time) from bpms_ru_done_task ru where process_ins_id = ru.main_process_ins_id
                    having  max(ru.create_time)>= to_date(''' ||
              beginTim ||
              ''',''yyyy-MM-dd HH24:mi:ss'')
                            and max(ru.create_time)<= to_date(''' ||
              endTIime || ''',''yyyy-MM-dd HH24:mi:ss''))';
  end if;
   if majorCondtion is not null  then
      sumStr := sumStr || ' and '||majorCondtion;
  end if;

  EXECUTE IMMEDIATE sumStr
    INTO sumCount;
  return sumCount;
END fun_get_module_count_range;
/
