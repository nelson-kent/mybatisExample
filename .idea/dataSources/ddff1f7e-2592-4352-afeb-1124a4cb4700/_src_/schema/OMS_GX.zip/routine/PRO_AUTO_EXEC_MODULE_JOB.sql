CREATE procedure PRO_AUTO_EXEC_MODULE_JOB as
begin
  declare
    job number;
    jobCount number;
    jobNO number;
    BEGIN
       --得到job 数 关于 PRO_COMTOP_MODULE_APPLY
       select count(*) into jobCount from ALL_JOBS t where t.WHAT = 'PRO_COMTOP_MODULE_APPLY;';
       if jobCount = 1 then
          select JOB into jobNO from ALL_JOBS t where t.WHAT = 'PRO_COMTOP_MODULE_APPLY;';
          dbms_job.remove(jobNO);
       end if;
      DBMS_JOB.SUBMIT(
        JOB => job,  /*自动生成JOB_ID*/
        WHAT => 'PRO_COMTOP_MODULE_APPLY;',  /*需要执行的过程或SQL语句*/
        NEXT_DATE =>  SYSDATE,  /*初次执行时间，8点30分*/
        INTERVAL => 'TRUNC(SYSDATE+1)+(12*60+30)/(24*60)'  /*每天8点*/
      );
      COMMIT;
    end;
end PRO_AUTO_EXEC_MODULE_JOB;

/
