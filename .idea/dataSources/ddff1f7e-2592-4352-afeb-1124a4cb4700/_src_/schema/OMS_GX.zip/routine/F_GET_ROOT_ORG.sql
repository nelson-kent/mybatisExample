CREATE function f_get_Root_Org return VARCHAR2 is
       rootOrg VARCHAR(40);
BEGIN
  SELECT t.org_id INTO rootOrg FROM top_organization t WHERE t.parent_org_id = '-1';

  return rootOrg;
end f_get_Root_Org;
/
