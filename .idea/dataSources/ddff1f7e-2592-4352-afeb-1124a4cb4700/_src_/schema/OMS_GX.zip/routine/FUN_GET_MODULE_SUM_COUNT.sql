CREATE FUNCTION fun_get_module_sum_count(field in varchar2,periodCount in number,isBefore in number,version in varchar2,moduleName in varchar2)
RETURN NUMBER IS
sumCount number;
sumStr  varchar2(1000);
isNull number;
BEGIN

    sumStr :='select  count(*) from  OMS_MODULE_STATISTICS_MANAGE where    Module_Name ='''||moduleName||'''and  Version ='||version||' and '||field ||' is not null ';
    EXECUTE IMMEDIATE sumStr INTO  isNull;
    if isBefore >0 and isNull >0 then
      sumStr :='select ' ||field|| ' from  OMS_MODULE_STATISTICS_MANAGE where    Module_Name ='''||moduleName||'''and  Version ='||version;
    else
      return periodCount;
    end if;
   EXECUTE IMMEDIATE sumStr INTO  sumCount;
   sumCount := sumCount + periodCount;
  return sumCount;
END fun_get_module_sum_count;
/
