CREATE function f_getMaxVal_In_TypeArray(val_array type_array) return number is
       i number(2) default 1;
       maxval number(2) default 0;
       curval number(2) default 0;
begin
  loop
       exit when(i> val_array.count) ;
       if val_array(i) is not null then
          curval := to_number(val_array(i));
          if curval > maxval then
             maxval := curval;
          end if;
       end if;
       i := i+1;
  end loop;
  return maxval;
end f_getMaxVal_In_TypeArray;

/
