CREATE PROCEDURE Pro_createTable_NotExist(souTableName varchar2,partTableName varchar2,userName varchar2) AUTHID CURRENT_USER is
PRAGMA AUTONOMOUS_TRANSACTION;
--souTableName      参考表名    如: PERSON
--partTableName     分表后缀    如: SH
--userName         流程编号    如: Process_DEMO
 num number;--当前已存在的数量
 exeSQL varchar2(1000);--要执行的建表SQL
 newTableName varchar2(40); --新表的表名
/******************************************************************************
   NAME:       Pro_createTable_NotExist
   PURPOSE:    当指定的表不存在时创建一个新表(要创建的表参考指定表的前缀，如创建PERSON_SH,表的参考表为：PERSON)
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2012-9-10      李小强        1. Created this procedure
******************************************************************************/
BEGIN
   newTableName:=souTableName||'_'||partTableName;--拼装新表表名
    --select count(1) into num from user_tables  where table_name= upper(newTableName);--查询是否有指定的表
   -- if num<1 then  --没有的时候
        --SELECT substr(newTableName,1,INSTR(newTableName, '_', -1, 1)-1) into partTableName FROM DUAL;--计算出分表后缀
        exeSQL:='create table '||userName||'.'||newTableName|| ' as  select * from ' ||userName||'.'||souTableName ||' where 1=2 ';--准备创建分表SQL
        execute immediate exeSQL;--执行创建分表SQL
        --查询数据表注释
      -- exeSQL:=' select table_name,''''COMMENT ON TABLE '''||newTableName|| ' is '''||comments||''';'
-- from user_tab_comments where table_name=''''||souTableName||'''';
        --查询数据字段注释
       -- select table_name,column_name,'COMMENT ON COLUMN '||table_name||'.'||column_name|| ' is '''||comments||''';'
-- from user_col_comments where table_name='BPMS_RU_PROCESS_INS'
   -- end if;

END Pro_createTable_NotExist;

/
