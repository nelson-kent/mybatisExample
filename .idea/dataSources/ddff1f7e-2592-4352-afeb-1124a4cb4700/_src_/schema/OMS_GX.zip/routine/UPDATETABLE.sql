CREATE FUNCTION updateTable (oldName IN varchar2,newName IN varchar2,newId IN varchar2)
return varchar
AS
begin
update  oms_ss_gx_work_plan set WORK_DEPARTMENT_ID = newId,
WORK_DEPARTMENT_NAME = newName
WHERE WORK_DEPARTMENT_NAME = oldName
return '3'
end;
/
