CREATE procedure p_online_extractData(c_date varchar2) AUTHID CURRENT_USER is
       start_time date;
       end_time date;
       str_start_time varchar2(100);
       str_end_time varchar2(100);
       current_time varchar2(100);
       c_time date;
       org_id varchar2(100);
       org_name varchar2(100);
       high_val number(6);
       tempsql varchar2(2000);
       intervalnum number(3) default 1;
       v_cnt NUMBER(10);
       v_temp_cnt NUMBER(10);
       dayhigh_id varchar2(32);
       --定义字段数组
       column_array type_array := type_array('count_0to1','count_1to2','count_2to3','count_3to4','count_4to5',
                                                             'count_5to6','count_6to7','count_7to8','count_8to9','count_9to10',
                                                             'count_10to11','count_11to12','count_12to13','count_13to14','count_14to15',
                                                             'count_15to16','count_16to17','count_17to18','count_18to19','count_19to20',
                                                             'count_20to21','count_21to22','count_22to23','count_23to24');
       --定义游标
       dayhighval_cursor sys_refcursor;
       rs_cursor sys_refcursor;
/******************************************************************************
       DATE       : 2014.04.30
       PURPOSE:统计每天每个小时各组织在线峰值
       parameter : c_date 统计哪天的数据 格式:2011-04-07 00:00:00
       需要
*******************************************************************************/
begin

 dbms_output.put_line('current_date'||to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
  --往临时表里面插入数据
  start_time := to_date(c_date ,'yyyy-mm-dd hh24:mi:ss');
  end_time := start_time + 1;

  select count(1) into v_cnt from user_tables where table_name = 'TEMP_LOGS';
  IF v_cnt = 0 THEN
        --创建会话级临时表，主要用来存储待处理的父节点ID数据、父节点名称，以及每次需要更新的登录次数、总数
        EXECUTE IMMEDIATE 'create global temporary table TEMP_LOGS(CURRENT_TIME DATE,
                                             org_name varchar2(128),
                                             ORG_ID VARCHAR2(40),
                                             HIGH_VAL number(10)) on commit Preserve  rows';
  ELSE
       EXECUTE IMMEDIATE 'truncate table TEMP_LOGS';
  END IF;


  --创建临时日志操作表，避免因日志操作表过大导致性能下降
  select count(1) into v_temp_cnt from user_tables where table_name = 'TEMP_TOP_LOG_USER_OPERATE';
  IF v_temp_cnt = 0 THEN
        --创建会话级临时表，主要用来存储待处理的父节点ID数据、父节点名称，以及每次需要更新的登录次数、总数
        EXECUTE IMMEDIATE 'create global temporary table TEMP_TOP_LOG_USER_OPERATE on commit Preserve rows as select * from top_log_user_operate where 1=2 ';

        --EXECUTE IMMEDIATE 'create global temporary table TEMP_TOP_LOG_USER_OPERATE(CURRENT_TIME DATE,
        --                             org_name varchar2(128),
        --                             ORG_ID VARCHAR2(40),
        --                             HIGH_VAL number(10)) on commit Preserve  rows';
  ELSE
       EXECUTE IMMEDIATE 'truncate table TEMP_TOP_LOG_USER_OPERATE';
  END IF;

  --EXECUTE IMMEDIATE 'insert into TEMP_TOP_LOG_USER_OPERATE select * from top_log_user_operate t where t.operate_time  between :1 and :2 and t.operate_type = 1' using start_time, end_time;

  EXECUTE IMMEDIATE 'insert into TEMP_TOP_LOG_USER_OPERATE
                             SELECT a.*
                              FROM (select *
                                    from TEMP_TOP_LOG_USER_OPERATE
                                    where OPERATE_TYPE = 1
                              ) a,top_log_user_login_detail b
                              WHERE a.operate_id = b.operate_id
                              AND b.exit_time is not null
                              and b.login_time  between :1 and :2'
                              using start_time, end_time;
/*
  loop
       --递增秒
       start_time := start_time+ 1/24/60/60 ;
       --dbms_output.put_line('start_time--'||to_char(start_time,'yyyy-mm-dd hh24:mi:ss'));
       exit when(start_time >=end_time);
       current_time := to_char(start_time,'yyyy-MM-dd hh24:mi:ss');
       tempsql := 'insert into temp_logs(current_time, org_id,org_name, high_val)
                             SELECT to_date('''||current_time||''',''yyyy-MM-dd hh24:mi:ss'') as curtime,
                                    a.ORG_ID,a.ORG_NAME,count(1)
                              FROM (select *
                                    from TEMP_TOP_LOG_USER_OPERATE
                                    where OPERATE_TYPE = 1
                              ) a,top_log_user_login_detail b
                              WHERE a.operate_id = b.operate_id
                              AND b.exit_time is not null
                              and to_date('''||current_time||''',''yyyy-MM-dd hh24:mi:ss'') between b.login_time and b.exit_time
                              group by a.ORG_ID,a.ORG_NAME';
       execute immediate tempsql;
  end loop;
  */
  loop
       --递增秒
       start_time := start_time+ 1/24 ;
       --dbms_output.put_line('start_time--'||to_char(start_time,'yyyy-mm-dd hh24:mi:ss'));
       exit when(start_time >=end_time);
       current_time := to_char(start_time,'yyyy-MM-dd hh24');
       tempsql := 'insert into temp_logs(current_time, org_id,org_name, high_val)
                              SELECT to_date('''||current_time||''',''yyyy-MM-dd hh24:mi:ss'') as curtime,
                                     a.ORG_ID,
                                     a.ORG_NAME,
                                     count(1)
                                FROM (select * from TOP_LOG_USER_OPERATE where OPERATE_TYPE = 1) a,
                                     top_log_user_login_detail b
                               WHERE a.operate_id = b.operate_id
                                 AND b.exit_time is not null
                                 and (b.login_time between
                                     to_date('''||current_time||':00:00'',''yyyy-MM-dd hh24:mi:ss'') and
                                     to_date('''||current_time||':59:59'',''yyyy-MM-dd hh24:mi:ss'') or
                                     b.exit_time between
                                     to_date('''||current_time||':00:00'',''yyyy-MM-dd hh24:mi:ss'') and
                                     to_date('''||current_time||':59:59'',''yyyy-MM-dd hh24:mi:ss'') or
                                     to_date('''||current_time||':00:00'',''yyyy-MM-dd hh24:mi:ss'') between
                                     b.login_time and b.exit_time)
                               group by a.ORG_ID, a.ORG_NAME';
       execute immediate tempsql;
  end loop;




  dbms_output.put_line('last_date'||to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));

  --开始分析操作
  start_time := to_date(c_date,'yyyy-mm-dd hh24:mi:ss');

  loop
       --遍历每个小时每个地市局下对当前系统的访问峰值。
       c_time := start_time + 1/24;
       exit when(c_time > end_time) ;
       str_start_time := to_char(start_time,'yyyy-MM-dd hh24:mi:ss');
       str_end_time := to_char(c_time,'yyyy-MM-dd hh24:mi:ss');
       tempsql := 'select max(high_val), org_name,org_id from temp_logs
                             where current_time >= to_date('''||str_start_time||''',''yyyy-MM-dd hh24:mi:ss'')
                             and current_time < to_date('''||str_end_time||''',''yyyy-MM-dd hh24:mi:ss'')
                             group by org_name,org_id ';
       --插入到当前的数据汇总表TOP_ONLINE_USER_STATISTICS
       open rs_cursor for tempsql;
       loop
           fetch rs_cursor into high_val, org_name, org_id;
           exit when rs_cursor%notfound;
           --merge into 作用：如果有则更新，如果没有则新增
           tempsql := 'merge into TOP_ONLINE_USER_STATISTICS a using (select '||high_val||' as high_val , '''||org_name||''' as org_name,
                             '''||org_id||''' as org_id,
                             to_date('''||c_date||''',''yyyy-mm-dd'') as c_date from dual) b
                             on (a.org_id = b.org_id and a.STATISTICS_TIME = b.c_date)
                             when matched then update set a.'||column_array(intervalnum)||' = b.high_val
                             when not matched then insert(ONLINE_STATITICS_ID, statistics_time, org_id,org_name, '||column_array(intervalnum)||')
                             values(sys_guid(), to_date(:1, ''yyyy-mm-dd''),:2,:3,:4)';
           execute immediate tempsql using c_date, org_id,org_name, high_val;
       end loop;
       if rs_cursor%isopen then
          close rs_cursor;
       end if;

       intervalnum := intervalnum + 1;
       start_time := c_time;
   end loop;
   --提交数据插入到TOP_ONLINE_USER_STATISTICS表中的操作
   commit;

  --统计一天中各组织的在线峰值
   open dayhighval_cursor for 'select ONLINE_STATITICS_ID, to_char(count_0to1),to_char(count_1to2),to_char(count_2to3),to_char(count_3to4),to_char(count_4to5),
                                                         to_char(count_5to6),to_char(count_6to7),to_char(count_7to8),to_char(count_8to9),to_char(count_9to10),
                                                         to_char(count_10to11),to_char(count_11to12),to_char(count_12to13),to_char(count_13to14),to_char(count_14to15),
                                                         to_char(count_15to16),to_char(count_16to17),to_char(count_17to18),to_char(count_18to19),to_char(count_19to20),
                                                         to_char(count_20to21),to_char(count_21to22),to_char(count_22to23),to_char(count_23to24) from TOP_ONLINE_USER_STATISTICS
                                                   where statistics_time =to_date('''||c_date||''',''yyyy-mm-dd'')';
   loop
       fetch dayhighval_cursor into dayhigh_id, column_array(1), column_array(2), column_array(3), column_array(4),column_array(5)
                                                            ,column_array(6),column_array(7),column_array(8),column_array(9),column_array(10),column_array(11)
                                                            ,column_array(12),column_array(13),column_array(14),column_array(15),column_array(16),column_array(17)
                                                            ,column_array(18),column_array(19),column_array(20),column_array(21),column_array(22),column_array(23)
                                                            ,column_array(24);
       exit when dayhighval_cursor%notfound;
       --得到当前数据当天的在线峰值
       high_val := f_getMaxval_in_typeArray(column_array);
       tempsql := 'update TOP_ONLINE_USER_STATISTICS set todaymaxcount = :1 where ONLINE_STATITICS_ID = :2';
       execute immediate tempsql using high_val, dayhigh_id;
   end loop;
   if dayhighval_cursor%isopen then
      close dayhighval_cursor;
   end if;
   commit;

 --将临时表干掉，会话级临时表需要truncate 之后才能干掉
  EXECUTE IMMEDIATE 'truncate table TEMP_LOGS';
  EXECUTE IMMEDIATE 'drop table TEMP_LOGS';

end p_online_extractData;

/
