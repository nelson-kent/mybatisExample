CREATE PROCEDURE Pro_commentTable_redef(souTableName varchar2,partTableName varchar2) AUTHID CURRENT_USER is
PRAGMA AUTONOMOUS_TRANSACTION;
--souTableName      参考表名    如: PERSON
--partTableName     分表后缀    如: SH
 comm varchar2(1000);--当前已存在的数量
 newTableName varchar2(40); --新表的表名
 varSql varchar2(1000);
 v_sql  VARCHAR2 (2000);
/******************************************************************************
   NAME:       Pro_commentTable_redef
   PURPOSE:    给分表后的新表加上表注释
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2013-8-21      殷海娟        1. Created this procedure
******************************************************************************/
CURSOR c
   IS
      SELECT *
        FROM user_col_comments
       WHERE table_name=souTableName;
BEGIN
   newTableName:=souTableName||'_'||partTableName;--拼装新表表名
   select comments into comm from user_tab_comments where table_name=upper(souTableName);
   varSql:='comment on table '|| newTableName ||' is '''||comm||'''';
   execute immediate varSql;
   FOR i IN c
   LOOP
      v_sql :=
            'COMMENT ON COLUMN '
         || newTableName
         || '.'
         || i.column_name
         || ' is '''
         || i.comments||'''';

      EXECUTE IMMEDIATE v_sql;
   END LOOP;
END Pro_commentTable_redef;

/
