CREATE FUNCTION fun_is_same_org(oldUser in varchar2,
                                           newUser in varchar2) --判断二个用户是否同时属于中调，地调，县调  1 表示同时属于 0 表示不属于
 RETURN NUMBER IS
  oldCount number;
  newCount number;
  sumStr   varchar2(1000);
  oldAttr  varchar2(100);
  newAttr  varchar2(100);
  oldStr   varchar2(1000);
  newStr   varchar2(1000);
  oldCode  varchar2(100);
  newCode  varchar2(100);
BEGIN
  sumStr := 'select count(*) from top_expand_attribute  where attri_object_id =''' ||
            oldUser || '''';
 -- dbms_output.put_line(sumStr);
  EXECUTE IMMEDIATE sumStr
    INTO oldCount;
  --dbms_output.put_line(sumStr);
  sumStr := 'select count(*) from top_expand_attribute  where attri_object_id =''' ||
            newUser || '''';
  EXECUTE IMMEDIATE sumStr
    INTO newCount;
  --dbms_output.put_line(newCount);
  if oldCount = 0 or newCount = 0 then
    return 0;
  end if;

  sumStr := 'select max(attribute_1) from top_expand_attribute  where attri_object_id =''' ||
            oldUser || '''';

  EXECUTE IMMEDIATE sumStr
    INTO oldAttr;
  -- dbms_output.put_line(oldAttr);

  sumStr := 'select max(attribute_1)  from top_expand_attribute  where attri_object_id =''' ||
            newUser || '''';
  EXECUTE IMMEDIATE sumStr
    INTO newAttr;
  --dbms_output.put_line(newAttr);
  if oldAttr != newAttr then
    return 0;
  end if;

  --  地调 和中调组织编码前四位相同，表示属于同一个地调和中调。
  if oldAttr = '3' or oldAttr = '4' then
    oldStr := 'select substr(org.org_code,0,4) from top_organization org
                 inner join  top_user us
                on us.org_id  = org.org_id
               where  us.employee_id =''' || oldUser || '''';
    newStr := 'select substr(org.org_code,0,4) from top_organization org
                 inner join  top_user us
                on us.org_id  = org.org_id
               where  us.employee_id =''' || newUser || '''';

  end if;
  -- 县调组织编码前六位相同，表示属于同一个县调。
  if oldAttr = '5' then
    oldStr := 'select substr(org.org_code,0,6) from top_organization org
                 inner join  top_user us
                on us.org_id  = org.org_id
               where  us.employee_id =''' || oldUser || '''';
    newStr := 'select substr(org.org_code,0,6) from top_organization org
                 inner join  top_user us
                on us.org_id  = org.org_id
               where  us.employee_id =''' || newUser || '''';
  end if;
  EXECUTE IMMEDIATE oldStr
    INTO oldCode;
  EXECUTE IMMEDIATE newStr
    INTO newCode;
  --如果编码相同 返回1
  if oldCode = newCode then
    return 1;
  end if;

  return 0;
END fun_is_same_org;
/
