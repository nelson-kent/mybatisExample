CREATE procedure p_org_visit_extractdata(c_date varchar2)
 AUTHID CURRENT_USER IS
  t_count      NUMBER(10);
  v_cnt NUMBER(10);
  t_statisticstime date;
/**************************************************************************************
            date:2013-11-16
            purpose:  统计每天每个部门下的登录次数及登录时长
            param: c_date 指定天 格式 2012-11-20
            需要
**************************************************************************************/
begin
  t_statisticstime := to_date(c_date, 'yyyy-mm-dd');
  select count(1) into v_cnt from user_tables where table_name = 'PID_COLLECTION';
  IF v_cnt = 0 THEN
        --创建会话级临时表，主要用来存储待处理的父节点ID数据、父节点名称，以及每次需要更新的登录次数、总数
        EXECUTE IMMEDIATE 'create global temporary table pid_collection(pid varchar2(32),
                                             org_name varchar2(128),
                                             LOGIN_COUNT number(10),
                                             TOTAL_TIME number(10,2)) on commit Preserve  rows';
  ELSE
       EXECUTE IMMEDIATE 'truncate table pid_collection';
   END IF;

  SELECT COUNT(1) INTO v_cnt FROM user_tables WHERE table_name = 'PID_COLLECTION_BETA';
  IF v_cnt = 0 THEN
     --创建一个一样的临时表，也是用来存储待处理的父节点ID数据，主要为了能交换数据
     EXECUTE IMMEDIATE 'create global temporary table pid_collection_beta(pid varchar2(32),
                                             org_name varchar2(128),
                                             LOGIN_COUNT number(10),
                                             TOTAL_TIME number(10,2)) on commit Preserve  rows';
  ELSE
        EXECUTE IMMEDIATE 'truncate table pid_collection_beta';
  END IF;

  --先删除表中今天统计的部门登录次数，防止重复插入
  DELETE FROM TOP_ORG_VISIT_DATA WHERE STATISTICS_TIME = t_statisticstime;
  --将指定时间下每个部门的登录次数及时长放入统计表中
  INSERT INTO TOP_ORG_VISIT_DATA(ORG_VISIT_ID,STATISTICS_TIME, ORG_ID, ORG_NAME, login_count, total_time)
  SELECT sys_guid(),t_statisticstime,org_ID,org_NAME, SUM(login_count) AS t_login_count , SUM(total_time)  AS t_total_time
  FROM top_user_visit_data
  WHERE STATISTICS_TIME = t_statisticstime
  GROUP BY ORG_ID,ORG_NAME
  HAVING (SUM(login_count)  > 0 OR SUM(total_time)  > 0);

  --将TOP_DEPARTMENT_USER_VISIT_DATA中存放的部门信息的父节点信息放入到临时表中
  EXECUTE IMMEDIATE 'INSERT INTO pid_collection(pid, org_name, LOGIN_COUNT, TOTAL_TIME)
                    SELECT  t1.org_id , t1.ORG_NAME, t2.t_login_count, t2.t_total_time
                    FROM  top_organization t1 inner join
                          ( select  b.PARENT_ORG_ID, sum(c.login_count) as t_login_count, sum(c.total_time) as t_total_time
                            FROM  top_org_visit_data c
                                  inner join top_organization b
                             ON c.ORG_ID = b.org_id
                             where  c.statistics_time = to_date('''||c_date||''', ''yyyy-mm-dd'')
                             AND b.PARENT_ORG_ID <> ''-1''
                             group by b.PARENT_ORG_ID
                            )  t2 on t1.org_id = t2.PARENT_ORG_ID';

   --更新TOP_DEPARTMENT_USER_VISIT_DATA表
   EXECUTE IMMEDIATE 'select count(1) from pid_collection' INTO t_count;
   WHILE t_count > 0  LOOP
   BEGIN
         EXECUTE IMMEDIATE 'MERGE INTO top_org_visit_data a
         USING (SELECT p1.pid, p1.org_name, LOGIN_COUNT AS t_login_count, TOTAL_TIME AS t_total_time
                       FROM pid_collection p1
                ) b  ON (a.org_id = b.pid and a.statistics_time =  to_date('''||c_date||''', ''yyyy-mm-dd''))
           WHEN MATCHED THEN
                UPDATE SET a.login_count = a.login_count + b.t_login_count, a.Total_Time = a.Total_Time + b.t_total_time
           WHEN NOT MATCHED THEN
                INSERT(ORG_VISIT_ID,statistics_time, ORG_ID, ORG_NAME, login_count, total_time)
                                VALUES(sys_guid(),to_date('''||c_date||''', ''yyyy-mm-dd''), b.pid, b.ORG_name, b.t_login_count, b.t_total_time)';
          EXECUTE IMMEDIATE 'truncate table pid_collection_beta';
          EXECUTE IMMEDIATE 'insert into pid_collection_beta(pid, org_name, LOGIN_COUNT, TOTAL_TIME)
                  SELECT  t1.org_id, t1.ORG_NAME, t2.t_login_count, t2.t_total_time
                    FROM  top_organization t1 inner join
                          ( select  b.PARENT_ORG_ID, sum(c.LOGIN_COUNT) as t_login_count, sum(c.TOTAL_TIME) as t_total_time
                            FROM  pid_collection c
                                  inner join top_organization b
                             ON c.pid = b.ORG_ID
                             where   b.PARENT_ORG_ID <> ''-1''
                             group by b.PARENT_ORG_ID
                            )  t2 on t1.org_id = t2.PARENT_ORG_ID';
           EXECUTE IMMEDIATE 'truncate table pid_collection';
           EXECUTE IMMEDIATE 'insert into pid_collection select * from pid_collection_beta';
           EXECUTE IMMEDIATE 'select count(1) from pid_collection ' INTO t_count;

   END;
   END LOOP;


   --将临时表干掉，会话级临时表需要truncate 之后才能干掉
   EXECUTE IMMEDIATE 'truncate table pid_collection_beta';
   EXECUTE IMMEDIATE 'drop table pid_collection_beta';
   EXECUTE IMMEDIATE 'truncate table pid_collection';
   EXECUTE IMMEDIATE 'drop table pid_collection';
end;

/
