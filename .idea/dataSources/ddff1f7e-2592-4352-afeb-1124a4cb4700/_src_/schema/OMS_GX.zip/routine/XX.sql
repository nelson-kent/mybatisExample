CREATE function xx ()return int
as
begin
  return 2
end xx
go
/
