CREATE PROCEDURE PRO_RU_RECOVER_TRH(processId        varchar2,
                                               mainProcessInsId varchar2) AUTHID CURRENT_USER IS

  /******************************************************************************
     NAME:       PRO_RU_RECOVER_TRH
     PURPOSE:  (根据流程ID、流程实例ID进行数据恢复)

     REVISIONS:
     Ver        Date        Author           Description
     ---------  ----------  ---------------  ------------------------------------
     1.0        2012-11-15          1. Created this procedure.


     Automatically available Auto Replace Keywords:
        Object Name:     PRO_RU_Remove_trh 流程实例数据恢复
        Sysdate:         2012-11-15
        Date and Time:   2012-11-15, 17:57:40, and 2012-11-15 17:57:40

  ******************************************************************************/
  process_redef_table_name varchar2(10); --记录流程定义所对应的分表后缀名
  redef_table_num          number(1); ---是否存在分表
  exeSQL                   varchar2(1000); --要执行SQL语句

  BPMS_RU_CC_TASK_TABLE     VARCHAR2(100); --抄送任务表名
  BPMS_RU_DONE_TASK_TABLE   VARCHAR2(100); --已办表名
  BPMS_RU_NODE_TRACK_TABLE  VARCHAR2(100); --节点跟踪表名
  BPMS_RU_PROCESS_INS_TABLE VARCHAR2(100); --流程实例表名
  BPMS_RU_TODO_TASK_TABLE   VARCHAR2(100); --待办表名
  BPMS_RU_VAR_TABLE         VARCHAR2(100); --变量表名

  BPMS_RU_ACTIVE_INS_TABLE  VARCHAR2(100); --活动实例表名
  BPMS_RU_NODE_ORBIT_TABLE  VARCHAR2(100); --节点轨迹表名
  BPMS_RU_TRANS_TRACK_TABLE VARCHAR2(100); --处理跟踪表名

  BPMS_RU_NODE_INS_TABLE VARCHAR2(100); --节点实例表名


  BPMS_RU_ATTACHMENT_TABLE VARCHAR2(100); --审批附件基本信息表名
  BPMS_RU_REVOKE_LOG_TABLE VARCHAR2(100); --流程撤回日志记录表名
  BPMS_RU_TODO_TASK_ALL_TABLE VARCHAR2(100); --待办任务总表表名
  BPMS_RU_COMPEVENT_INS_TB VARCHAR2(100); --补偿事件实例表名
  BPMS_RU_COMPEVENT_SUS_TB VARCHAR2(100); --补偿事件订阅表名
  BPMS_RU_MESEVENT_SUS_TABLE VARCHAR2(100); --消息事件订阅表名
  BPMS_RU_MESEVENT_TRI_TABLE VARCHAR2(100); --消息事件触发表表名
  BPMS_RU_SIGEVENT_TRI_TABLE VARCHAR2(100); --信号事件实例表表名
  BPMS_RU_SIGNEVENT_SUS_TABLE VARCHAR2(100); --信号事件订阅表表名

BEGIN

  if processId is not null then
    if mainProcessInsId is not null then

      select count(1) into redef_table_num from BPMS_CFG_REDEF_TABLE t1 where t1.PROCESS_ID = '' || processId || '';

      --step1:移除活动实例数据
      if redef_table_num > 0 then
        --当用户有对此流程定义分表时，加上分表后缀
        select t2.SUFFIX_FLAG into process_redef_table_name
          from BPMS_CFG_REDEF_TABLE t2  where t2.PROCESS_ID = '' || processId || '';

        BPMS_RU_CC_TASK_TABLE     := 'BPMS_RU_CC_TASK_' || process_redef_table_name;
        BPMS_RU_DONE_TASK_TABLE   := 'BPMS_RU_DONE_TASK_' || process_redef_table_name;
        BPMS_RU_NODE_TRACK_TABLE  := 'BPMS_RU_NODE_TRACK_' || process_redef_table_name;
        BPMS_RU_PROCESS_INS_TABLE := 'BPMS_RU_PROCESS_INS_' || process_redef_table_name;
        BPMS_RU_TODO_TASK_TABLE   := 'BPMS_RU_TODO_TASK_' || process_redef_table_name;
        BPMS_RU_VAR_TABLE         := 'BPMS_RU_VAR_' || process_redef_table_name;
        BPMS_RU_ACTIVE_INS_TABLE  := 'BPMS_RU_ACTIVE_INS_' || process_redef_table_name;
        BPMS_RU_NODE_ORBIT_TABLE  := 'BPMS_RU_NODE_ORBIT_' || process_redef_table_name;
        BPMS_RU_TRANS_TRACK_TABLE := 'BPMS_RU_TRANS_TRACK_' || process_redef_table_name;
        BPMS_RU_NODE_INS_TABLE    := 'BPMS_RU_NODE_INS_' || process_redef_table_name;
        BPMS_RU_ATTACHMENT_TABLE  := 'BPMS_RU_ATTACHMENT_' || process_redef_table_name;
        BPMS_RU_REVOKE_LOG_TABLE  := 'BPMS_RU_REVOKE_LOG_' || process_redef_table_name;
        BPMS_RU_TODO_TASK_ALL_TABLE:= 'BPMS_RU_TODO_TASK_ALL';
        BPMS_RU_COMPEVENT_INS_TB:='BPMS_RU_COMPEVENT_INS_'|| process_redef_table_name;
        BPMS_RU_COMPEVENT_SUS_TB:='BPMS_RU_COMPEVENT_SUS_'|| process_redef_table_name;
        BPMS_RU_MESEVENT_SUS_TABLE :='BPMS_RU_MESEVENT_SUS_'|| process_redef_table_name;
        BPMS_RU_MESEVENT_TRI_TABLE :='BPMS_RU_MESEVENT_TRI_'|| process_redef_table_name;
        BPMS_RU_SIGEVENT_TRI_TABLE :='BPMS_RU_SIGEVENT_TRI_'|| process_redef_table_name;
        BPMS_RU_SIGNEVENT_SUS_TABLE :='BPMS_RU_SIGNEVENT_SUS_'|| process_redef_table_name;
      else
        --不加后缀，直接查原表
        BPMS_RU_CC_TASK_TABLE     := 'BPMS_RU_CC_TASK';
        BPMS_RU_DONE_TASK_TABLE   := 'BPMS_RU_DONE_TASK';
        BPMS_RU_NODE_TRACK_TABLE  := 'BPMS_RU_NODE_TRACK';
        BPMS_RU_PROCESS_INS_TABLE := 'BPMS_RU_PROCESS_INS';
        BPMS_RU_TODO_TASK_TABLE   := 'BPMS_RU_TODO_TASK';
        BPMS_RU_VAR_TABLE         := 'BPMS_RU_VAR';
        BPMS_RU_ACTIVE_INS_TABLE  := 'BPMS_RU_ACTIVE_INS';
        BPMS_RU_NODE_ORBIT_TABLE  := 'BPMS_RU_NODE_ORBIT';
        BPMS_RU_TRANS_TRACK_TABLE := 'BPMS_RU_TRANS_TRACK';
        BPMS_RU_NODE_INS_TABLE    := 'BPMS_RU_NODE_INS';
        BPMS_RU_ATTACHMENT_TABLE  := 'BPMS_RU_ATTACHMENT';
        BPMS_RU_REVOKE_LOG_TABLE  := 'BPMS_RU_REVOKE_LOG';
        BPMS_RU_TODO_TASK_ALL_TABLE:= 'BPMS_RU_TODO_TASK_ALL';
        BPMS_RU_COMPEVENT_INS_TB:='BPMS_RU_COMPEVENT_INS';
        BPMS_RU_COMPEVENT_SUS_TB:='BPMS_RU_COMPEVENT_SUS';
        BPMS_RU_MESEVENT_SUS_TABLE :='BPMS_RU_MESEVENT_SUS';
        BPMS_RU_MESEVENT_TRI_TABLE :='BPMS_RU_MESEVENT_TRI';
        BPMS_RU_SIGEVENT_TRI_TABLE :='BPMS_RU_SIGEVENT_TRI';
        BPMS_RU_SIGNEVENT_SUS_TABLE :='BPMS_RU_SIGNEVENT_SUS';
      end if;

      --step2:拼装并插入实例数据--还原相关流程实例数据

      --直接依赖流程实例表
      --还原:抄送表数据
      exeSQL := ' insert into ' || BPMS_RU_CC_TASK_TABLE ||
                '  select * from BPMS_RU_CC_TASK_TRH c where c.main_process_ins_id =''' ||
                mainProcessInsId || '''';
      execute immediate exeSQL;
      --还原:已办任务数据
      exeSQL := ' insert into ' || BPMS_RU_DONE_TASK_TABLE ||
                ' select * from BPMS_RU_DONE_TASK_TRH c where c.main_process_ins_id =''' ||
                mainProcessInsId || '''';
      execute immediate exeSQL;
      --还原:节点跟踪数据
      exeSQL := ' insert into ' || BPMS_RU_NODE_TRACK_TABLE ||
                ' select * from BPMS_RU_NODE_TRACK_TRH k where k.main_process_ins_id =''' ||
                mainProcessInsId || '''';
      execute immediate exeSQL;
      --还原:流程实例数据
      exeSQL := 'insert into ' || BPMS_RU_PROCESS_INS_TABLE ||
                ' select * from  BPMS_RU_PROCESS_INS_TRH p where p.main_process_ins_id =''' ||
                mainProcessInsId || '''';
      execute immediate exeSQL;
      --还原:待办任务数据
      exeSQL := 'insert into ' || BPMS_RU_TODO_TASK_TABLE ||
                ' select * from BPMS_RU_TODO_TASK_TRH t where t.main_process_ins_id =''' ||
                mainProcessInsId || '''';
      execute immediate exeSQL;
      --还原:变量表数据
      exeSQL := 'insert into ' || BPMS_RU_VAR_TABLE ||
                ' select * from  BPMS_RU_VAR_TRH v where v.main_process_ins_id =''' ||
                mainProcessInsId || '''';
      execute immediate exeSQL;


      --间接依赖实例数据表
      --还原:活动实例数据
      exeSQL := 'insert into ' || BPMS_RU_ACTIVE_INS_TABLE ||
                ' select * from BPMS_RU_ACTIVE_INS_TRH a where exists (select 1  from
                BPMS_RU_NODE_INS_TRH n where a.node_ins_id = n.node_ins_id and n.main_process_ins_id =''' ||
                mainProcessInsId || ''')';
      execute immediate exeSQL;
      --还原:节点跟踪记录数据
      exeSQL := 'insert into ' || BPMS_RU_NODE_ORBIT_TABLE ||
                ' select * from BPMS_RU_NODE_ORBIT_TRH o where exists (select 1  from
                BPMS_RU_NODE_INS_TRH
                 n where o.cur_node_ins_id = n.node_ins_id and n.main_process_ins_id =''' ||
                mainProcessInsId || ''')';
      execute immediate exeSQL;
      --还原:办理跟踪明细数据
      exeSQL := 'insert into ' || BPMS_RU_TRANS_TRACK_TABLE ||
                ' select * from BPMS_RU_TRANS_TRACK_TRH r where exists (select 1  from
                BPMS_RU_NODE_INS_TRH  n where r.node_ins_id = n.node_ins_id and n.main_process_ins_id =''' ||
                mainProcessInsId || ''')';
      execute immediate exeSQL;

      --还原:节点实例表数据
      exeSQL := ' insert into  ' || BPMS_RU_NODE_INS_TABLE ||
                ' select * from BPMS_RU_NODE_INS_TRH n where n.main_process_ins_id = ''' ||
                mainProcessInsId || '''';
      execute immediate exeSQL;
     --还原：审批附件信息表数据
      exeSQL := 'insert into '|| BPMS_RU_ATTACHMENT_TABLE  ||
            ' select * from BPMS_RU_ATTACHMENT_TRH a where exists(select 1 from BPMS_RU_ACTIVE_INS_TRH
             b where a.act_ins_id = b.activity_ins_id and exists( select 1 from BPMS_RU_NODE_INS_TRH
             c where b.node_ins_id = c.node_ins_id and c.main_process_ins_id ='''||mainProcessInsId || '''))';
      execute immediate exeSQL;



     --还原：流程撤回日志记录表数据
      exeSQL := 'insert into ' || BPMS_RU_REVOKE_LOG_TABLE ||
            ' select * from  BPMS_RU_REVOKE_LOG_TRH a where exists(select 1 from BPMS_RU_ACTIVE_INS_TRH
             b where a.activity_ins_id = b.activity_ins_id and exists( select 1 from BPMS_RU_NODE_INS_TRH
             c where b.node_ins_id = c.node_ins_id and c.main_process_ins_id ='''||mainProcessInsId || '''))';
      execute immediate exeSQL;
      --还原：待办任务总表数据
      exeSQL := 'insert into '|| BPMS_RU_TODO_TASK_ALL_TABLE||
            ' select * from BPMS_RU_TODO_TASK_ALL_TRH a where exists(select 1 from BPMS_RU_ACTIVE_INS_TRH
             b where a.activity_ins_id = b.activity_ins_id and exists( select 1 from BPMS_RU_NODE_INS_TRH
             c where b.node_ins_id = c.node_ins_id and c.main_process_ins_id ='''||mainProcessInsId || '''))';
      execute immediate exeSQL;
      --还原：信号事件实例表数据
      exeSQL := 'insert into '|| BPMS_RU_COMPEVENT_INS_TB||
            ' select * from BPMS_RU_COMPEVENT_INS_TRH a where a.main_process_ins_id ='''||mainProcessInsId || '''';
      execute immediate exeSQL;
      --还原:补偿事件订阅表数据
      exeSQL := 'insert into '|| BPMS_RU_COMPEVENT_SUS_TB||
            ' select * from BPMS_RU_COMPEVENT_SUS_TRH a where a.main_process_ins_id ='''||mainProcessInsId || '''';
      execute immediate exeSQL;
      --还原:消息事件订阅表数据
      exeSQL := 'insert into '|| BPMS_RU_MESEVENT_SUS_TABLE||
            ' select * from BPMS_RU_MESEVENT_SUS_TRH a where a.main_process_ins_id ='''||mainProcessInsId || '''';
      execute immediate exeSQL;
      --还原:消息事件触发表数据
      exeSQL := 'insert into '||BPMS_RU_MESEVENT_TRI_TABLE||
            ' select * from BPMS_RU_MESEVENT_TRI_TRH a where a.main_process_ins_id ='''||mainProcessInsId || '''';
      execute immediate exeSQL;
      --还原:信号事件实例表数据
      exeSQL := 'insert into '||BPMS_RU_SIGEVENT_TRI_TABLE||
            ' select * from BPMS_RU_SIGEVENT_TRI_TRH a where a.main_process_ins_id ='''||mainProcessInsId || '''';
      execute immediate exeSQL;
      --还原:信号事件订阅表数据
      exeSQL := 'insert into '|| BPMS_RU_SIGNEVENT_SUS_TABLE||
            ' select * from BPMS_RU_SIGNEVENT_SUS_TRH a where a.main_process_ins_id ='''||mainProcessInsId || '''';
      execute immediate exeSQL;






      --step3:删除实例备份数据


      --直接依赖流程实例表

      --删除:信号事件订阅备份数据
      exeSQL := 'delete from BPMS_RU_SIGNEVENT_SUS_TRH a where a.main_process_ins_id ='''||mainProcessInsId || '''';
      execute immediate exeSQL;
      --删除信号事件实例备份数据
      exeSQL := 'delete from BPMS_RU_SIGEVENT_TRI_TRH a where a.main_process_ins_id ='''||mainProcessInsId || '''';
      execute immediate exeSQL;
      --删除消息事件触发备份数据
      exeSQL := 'delete from BPMS_RU_MESEVENT_TRI_TRH a where a.main_process_ins_id ='''||mainProcessInsId || '''';
      execute immediate exeSQL;
      --删除消息事件订阅备份数据
      exeSQL := 'delete from BPMS_RU_MESEVENT_SUS_TRH a where a.main_process_ins_id ='''||mainProcessInsId || '''';
      execute immediate exeSQL;
      --删除补偿事件订阅备份数据
      exeSQL := 'delete from BPMS_RU_COMPEVENT_SUS_TRH a where a.main_process_ins_id ='''||mainProcessInsId || '''';
      execute immediate exeSQL;
      --删除信号事件实例备份数据
      exeSQL := 'delete from BPMS_RU_COMPEVENT_INS_TRH a where a.main_process_ins_id ='''||mainProcessInsId || '''';
      execute immediate exeSQL;
      --删除待办任务总备份数据
      exeSQL := 'delete from BPMS_RU_TODO_TASK_ALL_TRH
             a where exists(select 1 from BPMS_RU_ACTIVE_INS_TRH
             b where a.activity_ins_id = b.activity_ins_id and exists( select 1 from BPMS_RU_NODE_INS_TRH
             c where b.node_ins_id = c.node_ins_id and c.main_process_ins_id ='''||mainProcessInsId || '''))';
      execute immediate exeSQL;
      --删除:流程撤回日志记录备份数据
      exeSQL := 'delete from BPMS_RU_REVOKE_LOG_TRH
             a where exists(select 1 from BPMS_RU_ACTIVE_INS_TRH
             b where a.activity_ins_id = b.activity_ins_id and exists( select 1 from BPMS_RU_NODE_INS_TRH
             c where b.node_ins_id = c.node_ins_id and c.main_process_ins_id ='''||mainProcessInsId || '''))';
      execute immediate exeSQL;
      --删除：审批附件信息备份数据
      exeSQL := 'delete from BPMS_RU_ATTACHMENT_TRH
             a where exists(select 1 from BPMS_RU_ACTIVE_INS_TRH
             b where a.act_ins_id = b.activity_ins_id and exists( select 1 from BPMS_RU_NODE_INS_TRH
             c where b.node_ins_id = c.node_ins_id and c.main_process_ins_id ='''||mainProcessInsId || '''))';
      execute immediate exeSQL;


      --删除抄送备份表数据
      exeSQL := ' delete from BPMS_RU_CC_TASK_TRH  c where c.main_process_ins_id =''' || mainProcessInsId || '''';
      execute immediate exeSQL;
      --删除已办备份表数据
      exeSQL := ' delete from BPMS_RU_DONE_TASK_TRH d where d.main_process_ins_id =''' || mainProcessInsId || '''';
      execute immediate exeSQL;
      --删除节点跟踪备份表数据
      exeSQL := ' delete from BPMS_RU_NODE_TRACK_TRH  k where k.main_process_ins_id =''' || mainProcessInsId || '''';
      execute immediate exeSQL;
      --删除流程实例备份数据
      exeSQL := 'delete from  BPMS_RU_PROCESS_INS_TRH p where p.main_process_ins_id =''' || mainProcessInsId || '''';
      execute immediate exeSQL;
      --删除待办任务备份数据
      exeSQL := 'delete from  BPMS_RU_TODO_TASK_TRH t where t.main_process_ins_id =''' || mainProcessInsId || '''';
      execute immediate exeSQL;
      --删除变量备份数据
      exeSQL := 'delete from  BPMS_RU_VAR_TRH v where v.main_process_ins_id =''' || mainProcessInsId || '''';
      execute immediate exeSQL;


      --间接依赖实例数据表

      --删除活动实例备份数据,
      exeSQL := ' delete from  BPMS_RU_ACTIVE_INS_TRH a where exists (select 1 from
                BPMS_RU_NODE_INS_TRH  n where a.node_ins_id = n.node_ins_id and n.main_process_ins_id =''' ||
                mainProcessInsId || ''')';
      execute immediate exeSQL;
      --删除节点轨迹备份数据
      exeSQL := 'delete from BPMS_RU_NODE_ORBIT_TRH o where exists (select 1 from
                BPMS_RU_NODE_INS_TRH  n where o.cur_node_ins_id = n.node_ins_id and n.main_process_ins_id =''' ||
                mainProcessInsId || ''')';
      execute immediate exeSQL;
      --删除办理跟踪备份数据
      exeSQL := 'delete from BPMS_RU_TRANS_TRACK_TRH r where exists (select 1 from
                BPMS_RU_NODE_INS_TRH  n where r.node_ins_id = n.node_ins_id and n.main_process_ins_id =''' ||
                mainProcessInsId || ''')';
      execute immediate exeSQL;
      --删除节点实例备份数据
      exeSQL := 'delete from  BPMS_RU_NODE_INS_TRH  n where n.main_process_ins_id = ''' || mainProcessInsId || '''';
      execute immediate exeSQL;

    end if;
  end if;
 -- commit;
END PRO_RU_RECOVER_TRH;

/
