CREATE PROCEDURE PRO_COMTOP_MODULE_APPLY
is
beginTime  varchar2(100); -- 开始时间
endTime   varchar2(100);--结束时间
begin
   endTime := to_char(sysdate,'yyyy-MM-dd HH24:mi:ss');
   beginTime := to_char(sysdate-1,'yyyy-MM-dd HH24:mi:ss');
   dbms_output.put_line(endTime);
   PRO_ZD_MODULE_APPLY(beginTime,endTime); --中调
   PRO_DD_MODULE_APPLY(beginTime,endTime); -- 地调
end PRO_COMTOP_MODULE_APPLY;
/
