CREATE FUNCTION getDefectStatistics (profession in OMS_OE_quality_evaluate.Profession%TYPE, defectType in OMS_OE_defect_statistics.DETECT_TYPE%TYPE) return varchar2
   as
defectnum integer;
begin
if profession = '通信'  then defectnum := 2;
elsif defectType = '紧急缺陷' or defectType = '重大缺陷' then defectnum := 2;
elsif defectType = '一般缺陷' or defectType = '其他缺陷' then defectnum := 1;
end if;
return defectnum;
end;

/
