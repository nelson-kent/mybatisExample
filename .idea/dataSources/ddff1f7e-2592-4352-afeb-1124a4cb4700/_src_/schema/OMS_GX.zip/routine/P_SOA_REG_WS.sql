CREATE PROCEDURE P_SOA_REG_WS (wsCode VARCHAR2,wsName VARCHAR2,wsFlag CHAR,methodCode VARCHAR2,
wsMemo VARCHAR2 ,tns varchar2 ,FAULT_ACTOR varchar2,FAULT_CODE varchar2 ,FAULT_STRING varchar2,wsClsss varchar2,authenticator varchar2 )IS

/******************************************************************************
   NAME:       P_SOA_REG_WS
   PURPOSE:  WS关联服务
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2014-4-8          1. Created this procedure.
******************************************************************************/
BEGIN
delete SOA_WEBSERVICE where WS_CODE = wsCode;
insert into SOA_WEBSERVICE(ws_id,WS_CODE,WS_NAME,WS_FLAG,METHOD_CODE,WS_MEMO,WS_NAMESPACE,
WS_FAULT_ACTOR ,WS_FAULT_CODE  ,WS_FAULT_STRING,WS_CLASS_ADDRESS,WS_AUTHENTICATOR_CLASS)  values
 (SEQ_SOA_WEBSERVICE_ID.NEXTVAL,wsCode ,wsName ,wsFlag ,methodCode ,wsMemo ,tns, FAULT_ACTOR ,FAULT_CODE ,FAULT_STRING,wsClsss,authenticator );

END P_SOA_REG_WS;

/
