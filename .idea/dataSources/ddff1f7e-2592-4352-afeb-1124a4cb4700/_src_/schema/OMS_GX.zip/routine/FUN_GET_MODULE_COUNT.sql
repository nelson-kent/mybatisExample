CREATE FUNCTION fun_get_module_count(orgCode   in varchar2,
                                                flowName  in varchar2,
                                                tableName in varchar2,
                                                beginTim  in varchar2,
                                                endTIime  in varchar2)
  RETURN NUMBER IS
  sumCount number;
  sumStr   varchar2(1000);
BEGIN

  if flowName is null then
    sumStr := 'select count(*) from ' || tableName ||
              ' where create_time>= to_date(''' || beginTim ||
              ''',''yyyy-MM-dd HH24:mi:ss'')
               and create_time<= to_date(''' || endTIime ||
              ''',''yyyy-MM-dd HH24:mi:ss'') and creator_id in (
        select  use.employee_id from top_user use  where use.org_id in(
              select org.org_id from top_organization org where   org.org_code like ''' ||
              orgCode || '%''))';
  elsif upper(tableName) = 'OMS_SS_COMMUNICATE_NET_OPEN' or upper(tableName) = 'OMS_PN_SETTINGVALUE_APPLY' then
    sumStr := 'select count(*) from ' || tableName ||
                ' where
                 exists(select max(ru.create_time) from bpms_ru_done_task ru where process_ins_id = ru.main_process_ins_id
                      having  max(ru.create_time)>= to_date(''' ||
                beginTim ||
                ''',''yyyy-MM-dd HH24:mi:ss'')
                              and max(ru.create_time)<= to_date(''' ||
                endTIime ||
                ''',''yyyy-MM-dd HH24:mi:ss''))
     and creator_id in (
          select  use.employee_id from top_user use  where use.org_id in(
                select org.org_id from top_organization org where   org.org_code like ''' ||
                orgCode || '%''))';

  else
    sumStr := 'select count(*) from ' || tableName ||
              ' where flow_state = 2
  and exists(select max(ru.create_time) from bpms_ru_done_task ru where process_ins_id = ru.main_process_ins_id
                    having  max(ru.create_time)>= to_date(''' ||
              beginTim ||
              ''',''yyyy-MM-dd HH24:mi:ss'')
                            and max(ru.create_time)<= to_date(''' ||
              endTIime ||
              ''',''yyyy-MM-dd HH24:mi:ss''))
   and creator_id in (
        select  use.employee_id from top_user use  where use.org_id in(
              select org.org_id from top_organization org where   org.org_code like ''' ||
              orgCode || '%''))';
  end if;

   dbms_output.put_line(sumStr);

  EXECUTE IMMEDIATE sumStr
    INTO sumCount;
  return sumCount;
END fun_get_module_count;

/
