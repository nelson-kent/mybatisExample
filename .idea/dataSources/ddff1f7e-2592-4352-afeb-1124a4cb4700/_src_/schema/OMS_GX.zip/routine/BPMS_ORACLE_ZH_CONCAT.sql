CREATE FUNCTION bpms_oracle_zh_concat(P1 VARCHAR2)
RETURN VARCHAR2 AGGREGATE USING bpms_oracle_zh_concat_im;

/
