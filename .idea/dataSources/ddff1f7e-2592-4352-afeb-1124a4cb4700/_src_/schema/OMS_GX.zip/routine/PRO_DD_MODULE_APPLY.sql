CREATE PROCEDURE PRO_DD_MODULE_APPLY(beginTime varchar2,
                                                endTime   varchar2) is

  cursor tableNameCur is
    select dic.moduleid,
           dic.flowname,
           dic.tablename,
           dic.majordistinguishcondition
      from T_TBP_COUNT_DIC dic
     where dic.factory = '康拓普'
       and type = '3';
  moduleId      T_TBP_COUNT_DIC.moduleid%type;
  flowName      T_TBP_COUNT_DIC.Flowname%type;
  tableName     T_TBP_COUNT_DIC.Tablename%type;
  majorCondtion T_TBP_COUNT_DIC.majordistinguishcondition%type;

  recordTime    date;
  TYPE emp_ssn_array IS TABLE OF NUMBER INDEX BY BINARY_INTEGER;
  best_employees emp_ssn_array;
begin
  recordTime := sysdate;
  open tableNameCur;
  loop
    fetch tableNameCur
      into moduleId, flowName, tableName, majorCondtion;
    exit when tableNameCur%notfound;
    if tableNameCur%found then
      -- 南宁
      best_employees(1) := fun_comtop_module_count('0401',
                                                   flowName,
                                                   tableName,
                                                   beginTime,
                                                   endTime,
                                                   majorCondtion);
      -- 柳州
      best_employees(3) := fun_comtop_module_count('0402',
                                                   flowName,
                                                   tableName,
                                                   beginTime,
                                                   endTime,
                                                   majorCondtion);

      -- 河池
      best_employees(5) := fun_comtop_module_count('0405',
                                                   flowName,
                                                   tableName,
                                                   beginTime,
                                                   endTime,
                                                   majorCondtion);

      -- 桂林
      best_employees(7) := fun_comtop_module_count('0403',
                                                   flowName,
                                                   tableName,
                                                   beginTime,
                                                   endTime,
                                                   majorCondtion);

      -- 梧州
      best_employees(9) := fun_comtop_module_count('0408',
                                                   flowName,
                                                   tableName,
                                                   beginTime,
                                                   endTime,
                                                   majorCondtion);

      -- 贺州
      best_employees(11) := fun_comtop_module_count('0414',
                                                    flowName,
                                                    tableName,
                                                    beginTime,
                                                    endTime,
                                                    majorCondtion);

      -- 北海
      best_employees(13) := fun_comtop_module_count('0409',
                                                    flowName,
                                                    tableName,
                                                    beginTime,
                                                    endTime,
                                                    majorCondtion);

      -- 防城港
      best_employees(15) := fun_comtop_module_count('0407',
                                                    flowName,
                                                    tableName,
                                                    beginTime,
                                                    endTime,
                                                    majorCondtion);

      -- 玉林
      best_employees(17) := fun_comtop_module_count('0404',
                                                    flowName,
                                                    tableName,
                                                    beginTime,
                                                    endTime,
                                                    majorCondtion);

      -- 钦州
      best_employees(19) := fun_comtop_module_count('0406',
                                                    flowName,
                                                    tableName,
                                                    beginTime,
                                                    endTime,
                                                    majorCondtion);

      -- 贵港
      best_employees(21) := fun_comtop_module_count('0410',
                                                    flowName,
                                                    tableName,
                                                    beginTime,
                                                    endTime,
                                                    majorCondtion);

      -- 崇左
      best_employees(23) := fun_comtop_module_count('0411',
                                                    flowName,
                                                    tableName,
                                                    beginTime,
                                                    endTime,
                                                    majorCondtion);

      -- 来宾
      best_employees(25) := fun_comtop_module_count('0412',
                                                    flowName,
                                                    tableName,
                                                    beginTime,
                                                    endTime,
                                                    majorCondtion);

      -- 百色
      best_employees(27) := fun_comtop_module_count('0413',
                                                    flowName,
                                                    tableName,
                                                    beginTime,
                                                    endTime,
                                                    majorCondtion);

      --地调新增数
      insert into T_TBP_COUNT_DDBUSI
        (RECORDID,
         RECORDTYPE,
         NANNING,
         LIUZHOU,
         HECHI,
         GUILIN,
         WUZHOU,
         HEZHOU,
         BEIHAI,
         FANGCHENGGANG,
         YULIN,
         QINZHOU,
         GUIGANG,
         CHONGZUO,
         LAIBIN,
         BAISE,
         RECORDTIME,
         MODULEID)
      values
        (sys_guid(),
         0,
         best_employees(1),
         best_employees(3),
         best_employees(5),
         best_employees(7),
         best_employees(9),
         best_employees(11),
         best_employees(13),
         best_employees(15),
         best_employees(17),
         best_employees(19),
         best_employees(21),
         best_employees(23),
         best_employees(25),
         best_employees(27),
         recordTime,
         moduleId);
    end if;
  end loop;
  close tableNameCur;
end PRO_DD_MODULE_APPLY;
/
