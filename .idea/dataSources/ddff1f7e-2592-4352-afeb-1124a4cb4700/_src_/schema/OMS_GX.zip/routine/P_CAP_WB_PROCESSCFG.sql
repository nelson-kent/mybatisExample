CREATE PROCEDURE P_CAP_WB_PROcessCfg(processId in varchar2,processName in varchar2,pathUrl in varchar2,pathType in number)IS
counNum NUMBER;
/******************************************************************************
   NAME:       P_CAP_WB_PROcessCfg
   PURPOSE:    processId:流程ID、processName：流程名称、pathUrl:连接地址、 pathType:地址类型：1、todo，2.done
   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2015/6/6   dingpang       1. Created this procedure.

   NOTES:插入工作台workbench_process_config表，待办/已办数据


******************************************************************************/
BEGIN
   --第一步先分析数据库中是否已有此数据
    select count(1) into counNum from workbench_process_config where process_id=processId;
    --如果存在，则做更新
    if(counNum = 0) then
           --插入已办的数据
        if (pathType=1)then
             insert into workbench_process_config (process_id,process_name,todo_url,done_url) values(processId,processName,pathUrl,' ');

        end if ;
            --插入待办数据
        if(pathType=2)then
                insert into workbench_process_config (process_id,process_name,todo_url,done_url) values(processId,processName,' ',pathUrl);
            end if ;
       end if ;

      --更新已办的数据
      if(counNum > 0) then
        if (pathType=1)then
           update workbench_process_config set todo_url =pathUrl where  process_id=processId;
        end if;
            --更新待办数据
         if(pathType=2) then
            update workbench_process_config set done_url =pathUrl where  process_id=processId;
         end if;
       end if;
commit;
END P_CAP_WB_PROcessCfg;

/
