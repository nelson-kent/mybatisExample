CREATE procedure pro_page_copyPage(pageId in varchar,currentTime in varchar) as
--pageId 待复制的页面Id
--currentTime 当前时间，用于MD5算法获取新的id
/******************************************************************************
   NAME:       pro_page_copyPage
   PURPOSE:    拷贝界面
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2015-6-3     李小芬           1. Created this procedure
******************************************************************************/
begin
     -- page
    insert into cip_page
    select MD5(currentTime || cp.page_id) page_id,
           cp.package_id,
           cp.stereotype_id,
           cp.entity_id,
           substr(cp.eng_name,0,length(cp.eng_name)-4) || currentTime || '.jsp' eng_name,--拼装新的界面名称
           cp.title || currentTime  title,
           cp.path,
           cp.height,
           cp.width,
           cp.description,
           cp.encoding,
           cp.type_code
      from cip_page cp
     where cp.page_id = pageId;
     -- config
      insert into cip_page_config
     select MD5(currentTime ||  pc.config_id) config_id,
            MD5(currentTime ||  pc.page_id) page_id,
            pc.custom_css,
            pc.ch_name,
            pc.eng_name,
            pc.description,
            pc.custom_js
       from cip_page_config pc
      where pc.page_id = pageId;
      -- header
      insert into cip_page_header
      select MD5(currentTime ||  ph.header_id) header_id,
             MD5(currentTime ||  ph.config_id) config_id,
             ph.type,
             ph.path,
             ph.ch_name,
             ph.eng_name,
             ph.description,
             ph.sort_no
        from cip_page_header ph, cip_page_config pc
       where ph.config_id = pc.config_id
         and pc.page_id = pageId;
         -- area
         insert into cip_page_area
     select MD5(currentTime ||  pa.area_id) area_id,
            MD5(currentTime ||  pa.config_id) config_id,
            pa.entity_eng_name,
            pa.code,
            pa.type,
            pa.layout,
            pa.ch_name,
            pa.eng_name,
            pa.description,
            MD5(currentTime ||  pa.area_item_id) area_item_id,
            pa.method_eng_name,
            pa.item_name,
            pa.entity_package_id
       from cip_page_area pa, cip_page_config pc
      where pa.config_id = pc.config_id
        and pc.page_id = pageId;
        --areaitem1
         insert into cip_page_areaitem
        select MD5(currentTime ||  ai.areaitem_id) areaitem_id,
               MD5(currentTime ||  ai.area_id) area_id,
               ai.parent_id,
               ai.ch_name,
               ai.eng_name,
               ai.sort_no,
               ai.col_size,
               ai.description,
               ai.alignment,
               ai.requried,
               ai.item_type,
               ai.item_prefix,
               ai.show_flag
          from cip_page_areaitem ai, cip_page_area pa, cip_page_config pc
         where ai.area_id = pa.area_id
           and pa.config_id = pc.config_id
           and pc.page_id = pageId;
           -- areaitem2 for grid
            insert into cip_page_areaitem
        select MD5(currentTime ||  ai.areaitem_id) areaitem_id,
               MD5(currentTime ||  ai.area_id) area_id,
               ai.parent_id,
               ai.ch_name,
               ai.eng_name,
               ai.sort_no,
               ai.col_size,
               ai.description,
               ai.alignment,
               ai.requried,
               ai.item_type,
               ai.item_prefix    ,
               ai.show_flag
          from cip_page_areaitem ai, cip_page_area pa, cip_page_config pc
         where ai.areaitem_id = pa.area_item_id
           and pa.config_id = pc.config_id
           and pc.page_id = pageId;
           --property
           insert into cip_page_property
      select MD5(currentTime ||  pp.property_id) property_id,
             MD5(currentTime ||  pp.areaitem_id) areaitem_id,
             pp.name,
             pp.value,
             pp.is_common,
             pp.ch_name,
             pp.eng_name,
             pp.description
        from cip_page_property pp,
             cip_page_areaitem ai,
             cip_page_area     pa,
             cip_page_config   pc
       where pp.areaitem_id = ai.areaitem_id
         and ai.area_id = pa.area_id
         and pa.config_id = pc.config_id
         and pc.page_id = pageId;
         --property for grid
         insert into cip_page_property
      select MD5(currentTime ||  pp.property_id) property_id,
             MD5(currentTime ||  pp.areaitem_id) areaitem_id,
             pp.name,
             pp.value,
             pp.is_common,
             pp.ch_name,
             pp.eng_name,
             pp.description
        from cip_page_property pp,
             cip_page_areaitem ai,
             cip_page_area     pa,
             cip_page_config   pc
       where pp.areaitem_id = ai.areaitem_id
         and ai.areaitem_id = pa.area_item_id
         and pa.config_id = pc.config_id
         and pc.page_id = pageId;
end pro_page_copyPage;

/
