CREATE procedure PRO_MOVE_HISTORY_DATA(monthNum Number ) IS
/****************************************************************************************************************
    迁移日志表中TOP_CORE_LOGIN_LOGS 表中历史数据至TOP_CORE_LOGIN_LOGS_HISTORY
    date：2013-11-08
    param：monthNum 需要把距当前时间几个月前的数据移到历史表中
    需要
********************************************************************************************************************/
   beforedate DATE;
   datename varchar2(6);
   tablename varchar2(100);
BEGIN
     --找到当前日期的前monthNum个月的时间
     beforedate := add_months(sysdate, -monthNum) ;
     datename := to_char(beforedate,'yyyyMM');

     --迁移至历史表，修改表名
     tablename := 'TOP_LOG_USER_OPERATE' || '_' || datename;

    execute immediate
     'alter table  TOP_LOG_USER_OPERATE rename to '|| tablename ;

     execute immediate
     'create table TOP_LOG_USER_OPERATE as select  * from ' || tablename;

     execute immediate
     'truncate table TOP_LOG_USER_OPERATE';



     tablename := 'TOP_LOG_USER_OPERATE_DETAIL' || '_' || datename;

     execute immediate
     'alter table  TOP_LOG_USER_OPERATE_DETAIL rename to '|| tablename ;

     execute immediate
     'create table TOP_LOG_USER_OPERATE_DETAIL as select  * from ' || tablename;

     execute immediate
     'truncate table TOP_LOG_USER_OPERATE_DETAIL';


     tablename := 'TOP_LOG_USER_LOGIN_DETAIL' || '_' || datename;

     execute immediate
     'alter table  TOP_LOG_USER_LOGIN_DETAIL rename to '|| tablename ;

     execute immediate
     'create table TOP_LOG_USER_LOGIN_DETAIL as select  * from ' || tablename;

     execute immediate
     'truncate table TOP_LOG_USER_LOGIN_DETAIL';


     tablename := 'TOP_LOG_FUN_DETAIL' || '_' || datename;

     execute immediate
     'alter table  TOP_LOG_FUN_DETAIL rename to '|| tablename ;

     execute immediate
     'create table TOP_LOG_FUN_DETAIL as select  * from ' || tablename;

     execute immediate
     'truncate table TOP_LOG_FUN_DETAIL';

    COMMIT;
exception
  when others then
    rollback;

END PRO_MOVE_HISTORY_DATA;

/
