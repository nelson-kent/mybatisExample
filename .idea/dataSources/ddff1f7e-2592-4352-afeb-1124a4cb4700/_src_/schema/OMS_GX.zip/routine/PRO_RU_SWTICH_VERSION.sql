CREATE PROCEDURE PRO_RU_SWTICH_VERSION(processId varchar2,intanceId varchar2,targetVersion number) AUTHID CURRENT_USER is

/******************************************************************************
   NAME:       PRO_RU_SWTICH_VERSION_TRH
   PURPOSE:    流程版本切换更新运行时表

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2014-7-5    翟羽佳       Created this procedure.
******************************************************************************/
process_redef_table_name varchar2(10); --记录流程定义所对应的分表后缀名
redef_table_num          number(1); ---是否存在分表
c_colFlag                number;  --协作标识位
c_newestColVersion       number;  --最新协作版本
exeSQL                   varchar2(1000); --要执行SQL语句
BPMS_RU_TODO_TASK_TABLE      VARCHAR2(100); --待办表名
BPMS_RU_DONE_TASK_TABLE      VARCHAR2(100); --已办表名
BPMS_RU_PROCESS_INS_TABLE    VARCHAR2(100); --流程实例表名
BPMS_RU_NODE_INS_TABLE       VARCHAR2(100); --节点实例表名
BPMS_RU_SIGEVENT_TRI_TABLE   VARCHAR2(100); --信号事件实例表表名
BPMS_RU_SIGNEVENT_SUS_TABLE  VARCHAR2(100); --信号事件订阅表表名
BPMS_RU_MESEVENT_SUS_TABLE   VARCHAR2(100); --消息事件订阅表名
BPMS_RU_MESEVENT_TRI_TABLE   VARCHAR2(100); --消息事件触发表表名

BEGIN

	select count(1) into redef_table_num from BPMS_CFG_REDEF_TABLE t1 where t1.PROCESS_ID = '' || processId || '';

      --step1:加分表
      if redef_table_num > 0 then
        --当用户有对此流程定义分表时，加上分表后缀
        select t2.SUFFIX_FLAG into process_redef_table_name
          from BPMS_CFG_REDEF_TABLE t2  where t2.PROCESS_ID = '' || processId || '';

        BPMS_RU_DONE_TASK_TABLE   := 'BPMS_RU_DONE_TASK_' || process_redef_table_name;
        BPMS_RU_PROCESS_INS_TABLE := 'BPMS_RU_PROCESS_INS_' || process_redef_table_name;
        BPMS_RU_TODO_TASK_TABLE   := 'BPMS_RU_TODO_TASK_' || process_redef_table_name;
        BPMS_RU_NODE_INS_TABLE    := 'BPMS_RU_NODE_INS_' || process_redef_table_name;
        BPMS_RU_MESEVENT_SUS_TABLE :='BPMS_RU_MESEVENT_SUS_'|| process_redef_table_name;
        BPMS_RU_MESEVENT_TRI_TABLE :='BPMS_RU_MESEVENT_TRI_'|| process_redef_table_name;
        BPMS_RU_SIGEVENT_TRI_TABLE :='BPMS_RU_SIGEVENT_TRI_'|| process_redef_table_name;
        BPMS_RU_SIGNEVENT_SUS_TABLE :='BPMS_RU_SIGNEVENT_SUS_'|| process_redef_table_name;
      else
        --不加后缀，直接查原表
        BPMS_RU_DONE_TASK_TABLE   := 'BPMS_RU_DONE_TASK';
        BPMS_RU_PROCESS_INS_TABLE := 'BPMS_RU_PROCESS_INS';
        BPMS_RU_TODO_TASK_TABLE   := 'BPMS_RU_TODO_TASK';
        BPMS_RU_NODE_INS_TABLE    := 'BPMS_RU_NODE_INS';
        BPMS_RU_MESEVENT_SUS_TABLE :='BPMS_RU_MESEVENT_SUS';
        BPMS_RU_MESEVENT_TRI_TABLE :='BPMS_RU_MESEVENT_TRI';
        BPMS_RU_SIGEVENT_TRI_TABLE :='BPMS_RU_SIGEVENT_TRI';
        BPMS_RU_SIGNEVENT_SUS_TABLE :='BPMS_RU_SIGNEVENT_SUS';
      end if;

	--step2:更新协作运行时
	select count(1)
    into c_colFlag
    from bpms_ru_col_ins ci
    where ci.main_process_ins_id = intanceId;

	 --如果存在协作信息，则更新协作允许表里的版本
      if c_colFlag > 0 then
        select max(c.col_version)
        into c_newestColVersion
    	from bpms_def_col_process p, bpms_def_col c
   	 where p.process_id = processId
   	 and p.process_version = targetVersion
    	 and p.col_dbid = c.col_dbid;
	  --更新协作运行时表
      exeSQL :=' update bpms_ru_col_ins ci set ci.col_version = '''||c_newestColVersion||'''
	  where ci.main_process_ins_id = '''||intanceId||'''';
	  execute immediate exeSQL;
      --更新协作运行时消息发送表
	  exeSQL :=' update bpms_ru_col_send_message sm set sm.col_version = '''||c_newestColVersion||'''
	  where sm.s_main_process_ins_id = '''||intanceId||'''  or sm.r_main_process_ins_id = '''||intanceId||'''';
	  execute immediate exeSQL;
	   --更新协作运行时消息接收表
      exeSQL :=' update bpms_ru_col_receive_message rm set rm.col_version = '''||c_newestColVersion||'''
	  where rm.s_main_process_ins_id = '''||intanceId||'''  or rm.r_main_process_ins_id = '''||intanceId||'''';
	  execute immediate exeSQL;
      end if;

	--step3:更新私有流程允许时
	--更新待办
	exeSQL :=' update '||BPMS_RU_TODO_TASK_TABLE||' set  version = '''||targetVersion||'''
	where main_process_ins_id = '''||intanceId||'''';
	execute immediate exeSQL;
	--更新已办
    exeSQL :=' update '||BPMS_RU_DONE_TASK_TABLE||' set version = '''||targetVersion||'''
	where main_process_ins_id = '''||intanceId||'''';
	execute immediate exeSQL;
	--更新流程实例
     exeSQL :=' update '||BPMS_RU_PROCESS_INS_TABLE||' set version = '''||targetVersion||'''
	 where main_process_ins_id = '''||intanceId||'''';
	 execute immediate exeSQL;
	--更新节点实例
    exeSQL :=' update '||BPMS_RU_NODE_INS_TABLE||'  set process_version = '''||targetVersion||''' where main_process_ins_id = '''||intanceId||'''';
	execute immediate exeSQL;
	--更新信号事件实例
    exeSQL :=' update '||BPMS_RU_SIGEVENT_TRI_TABLE||'   set  version = '''||targetVersion||''' where main_process_ins_id = '''||intanceId||'''';
	execute immediate exeSQL;
	--更新信号事件订阅
    exeSQL :=' update '||BPMS_RU_SIGNEVENT_SUS_TABLE||'  set  version = '''||targetVersion||''' where main_process_ins_id = '''||intanceId||'''';
	execute immediate exeSQL;
	--更新消息事件订阅
    exeSQL :=' update '||BPMS_RU_MESEVENT_SUS_TABLE|| '  set  version = '''||targetVersion||''' where main_process_ins_id = '''||intanceId||'''';
	execute immediate exeSQL;
	--更新消息事件实例
    exeSQL :=' update '||BPMS_RU_MESEVENT_TRI_TABLE||'  set  version = '''||targetVersion||''' where main_process_ins_id = '''||intanceId||'''';
	execute immediate exeSQL;

END PRO_RU_SWTICH_VERSION;

/
