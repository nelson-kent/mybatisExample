CREATE FUNCTION data(oldName IN  varchar2(40),newName IN  varchar2(40),
newId IN  varchar2(40))
return ok varchar(2)
AS
begin
update  oms_ss_gx_work_plan set WORK_DEPARTMENT_ID = newId,
WORK_DEPARTMENT_NAME = newName
WHERE WORK_DEPARTMENT_NAME = oldName
return '3'
end updateTable
go
/
