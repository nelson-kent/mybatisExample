CREATE procedure PRO_initRealPostByStandCode(postCode varchar2) IS
/*PRO_INITREALPOSTBYSTANDCODE*************************************************************************************************************
    purpose:根据标准岗位ID编码，刷新该标准岗位关联的实际岗位以及实际岗位下的人员角色权限信息
            处理逻辑：先删除实际岗位关联的所有权限信息，再根据标准岗位的权限初始化。
    param:postCode 标准岗位ID编码，可放置多个值，以英文逗号隔开，例如 ZH_ZC,ZH_WZ
**************************************************************************************************************/
     arr_codes type_array := type_array();
     v_stand_code VARCHAR2(200);
BEGIN
     arr_codes := f_split(postCode,',');
     IF arr_codes.COUNT > 0 THEN
        FOR i IN arr_codes.FIRST .. arr_codes.LAST
        LOOP
            v_stand_code := arr_codes(i);
            IF v_stand_code IS NOT NULL THEN
               --删除关联了标准岗位的实际岗位下的人员角色权限
               DELETE FROM top_per_subject_role
               WHERE SUBJECT_CLASSIFY_CODE = 'USER'
               AND (subject_id, role_id) IN (
                       SELECT t_user.user_id, t_role.role_id
                       FROM (SELECT b.User_Id
                           FROM top_post a INNER JOIN top_user_post_relation b
                                ON a.post_id = b.post_id
                           WHERE a.standard_post_code = v_stand_code
                                 AND a.state = 1 ) t_user,
                           (SELECT b.role_id
                              FROM top_post a INNER JOIN top_per_subject_role b
                                   ON a.post_id = b.subject_id
                              WHERE a.standard_post_code = v_stand_code
                                    AND a.state = 1
                                    AND b.SUBJECT_CLASSIFY_CODE = 'POST') t_role )
                     and role_id in  (
                                 select ps.role_id from top_post_other p,top_per_subject_role ps
                                      where p.other_post_id=ps.subject_id
                                      and p.state=1
                                      and ps.subject_classify_code='POST'
                                      AND p.other_post_flag=2
                                      and p.other_post_id=v_stand_code
                            );
               --删除关联了标准岗位的实际岗位与角色的关联
               DELETE FROM top_per_subject_role
                      WHERE SUBJECT_CLASSIFY_CODE = 'POST'
                            AND (role_id, subject_id) IN (
                                SELECT b.role_id, a.post_id
                                FROM top_post a INNER JOIN top_per_subject_role b
                                     ON a.post_id = b.subject_id
                                WHERE a.standard_post_code = v_stand_code
                                      AND a.state = 1
                                      AND b.SUBJECT_CLASSIFY_CODE = 'POST' )
                           and role_id in  (
                                 select ps.role_id from top_post_other p,top_per_subject_role ps
                                      where p.other_post_id=ps.subject_id
                                      and p.state=1
                                      and ps.subject_classify_code='POST'
                                      and p.other_post_flag=2
                                      and p.other_post_id=v_stand_code
                            );
               --新增实际岗位与角色的关联
               INSERT INTO top_per_subject_role(subject_role_id, role_id, subject_id, subject_classify_code,
                      creator_id, create_time)
               SELECT sys_guid(), t_role.role_id, t_post.post_id, 'POST', 'SuperAdmin', SYSDATE
               FROM ( SELECT b.role_id
               FROM top_post_other a INNER JOIN top_per_subject_role b
                    ON a.other_post_id = b.subject_id
               WHERE a.other_post_id = v_stand_code  and a.other_post_flag=2  AND a.state = 1 AND a.other_post_flag=2
                     AND b.SUBJECT_CLASSIFY_CODE = 'POST' ) t_role,
               (SELECT c.post_id FROM top_post c
                 WHERE c.standard_post_code = v_stand_code AND c.state = 1 ) t_post;
               --新增实际岗位下用户与角色的关联
               INSERT INTO TOP_PER_SUBJECT_ROLE(subject_role_id, role_id, subject_id, Subject_Classify_Code,
                      CREATOR_ID,CREATE_TIME)
                SELECT SYS_GUID(), ROLE_ID, USER_ID, 'USER','SuperAdmin',SYSDATE
                FROM ( SELECT DISTINCT a.role_id, b.user_id
                			FROM top_per_subject_role a INNER JOIN  top_user_post_relation b
                				 ON a.subject_id = b.post_id
                			WHERE EXISTS (
                				  SELECT 1  FROM ( SELECT b.post_id FROM top_post b
                						  WHERE b.standard_post_code = v_stand_code) p
                				  WHERE p.post_id = a.subject_id
                			) AND a.subject_classify_code = 'POST')
                  WHERE role_id in  (
                                 select ps.role_id from top_post_other p,top_per_subject_role ps
                                      where p.other_post_id=ps.subject_id
                                      and p.state=1
                                      and ps.subject_classify_code='POST'
                                      and p.other_post_flag=2
                                      and p.other_post_id=v_stand_code
                            );
            END IF;
        END LOOP;
     END IF;
     COMMIT;
end PRO_initRealPostByStandCode;

/
