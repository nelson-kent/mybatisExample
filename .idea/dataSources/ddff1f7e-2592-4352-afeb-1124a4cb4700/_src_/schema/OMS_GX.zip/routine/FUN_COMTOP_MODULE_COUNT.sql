CREATE FUNCTION fun_comtop_module_count(orgCode       in varchar2,
                                                   flowName      in varchar2,
                                                   tableName     in varchar2,
                                                   beginTim      in varchar2,
                                                   endTIime      in varchar2,
                                                   majorCondtion in varchar2)
  RETURN NUMBER IS
  sumCount number;
  sumStr   varchar2(1000);
BEGIN
   if tableName is null then
     return 0;
   end if;
  --专网资源申请 、定值申请因为是接口流转，不好判断是否归档，只要入OMS库就算归档 20170316 谭杰
  if ((flowName is null
     or upper(tableName) = 'OMS_SS_COMMUNICATE_NET_OPEN'
     or upper(tableName) = 'OMS_PN_SETTINGVALUE_APPLY' ) and orgCode != '0460') then
    sumStr := 'select count(*) from ' || tableName ||
          ' where create_time >= to_date(''' || beginTim ||
          ''',''yyyy-MM-dd HH24:mi:ss'')
           and create_time<= to_date(''' || endTIime ||
          ''',''yyyy-MM-dd HH24:mi:ss'') and creator_id in (
      select  use.employee_id from top_user use  where use.org_id in(
          select org.org_id from top_organization org where   org.org_code like ''' ||
          orgCode || '%''))';

  else if((flowName is null
     or upper(tableName) = 'OMS_SS_COMMUNICATE_NET_OPEN'
     or upper(tableName) = 'OMS_PN_SETTINGVALUE_APPLY' ) and orgCode = '0460') then
      sumStr := 'select count(*) from ' || tableName ||
            ' where create_time >= to_date(''' || beginTim ||
            ''',''yyyy-MM-dd HH24:mi:ss'')
             and create_time<= to_date(''' || endTIime ||
            ''',''yyyy-MM-dd HH24:mi:ss'') and (creator_id in (
        select  use.employee_id from top_user use  where use.org_id in(
            select org.org_id from top_organization org where   org.org_code like ''' ||
            orgCode || '%'')) or creator_id = ''SuperAdmin'')';

  else if(flowName is not null ) then
    sumStr := 'select count(*) from ' || tableName ||
          ' where flow_state = 2
      and exists(select max(ru.create_time) from bpms_ru_done_task ru where process_ins_id = ru.main_process_ins_id
              having  max(ru.create_time) >= to_date(''' ||
            beginTim ||
            ''',''yyyy-MM-dd HH24:mi:ss'')
                  and max(ru.create_time)<= to_date(''' ||
            endTIime ||
            ''',''yyyy-MM-dd HH24:mi:ss''))
       and exists(select 1 from bpms_ru_done_task ru ,top_user use ,top_organization org  where process_ins_id = ru.main_process_ins_id
              and ru.TRANS_ACTOR_ID = use.EMPLOYEE_ID and use.ORG_ID = org.org_id
              and ru.status = 1
          and org.org_code like ''' || orgCode || '%''
         )';
    end if;
  end if ;
  end if;
  if majorCondtion is not null  then
      sumStr := sumStr || ' and '||majorCondtion;
  end if;

  EXECUTE IMMEDIATE sumStr
    INTO sumCount;
  if tableName = 'OMS_SS_BASEBUILDENTER' then
    sumCount := sumCount * 3;
  end if;
  return sumCount;
END fun_comtop_module_count;
/
