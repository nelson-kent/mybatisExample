CREATE PROCEDURE PRO_FORM_STATISTISTICS(beginTime varchar2,
                                                    endTime   varchar2,
                                                    firstDayTime varchar2,
                                                    organCode varchar2,  
                                                    optionType varchar2,  
                                                    sq varchar2,
                                                    area varchar2
                                                    ) is
  cursor tableNameCur is
    select dic.mkm,
           dic.ywsx,
           dic.bdbh,
           dic.bdm,
           dic.ywid,
           dic.db_table_name,
           dic.flow_name,
           dic.condition --查询条件组合
      from ZD_STATISTISTICS_FORM dic ;
  ywsx      ZD_STATISTISTICS_FORM.ywsx%type;  --业务事项
  ywid      ZD_STATISTISTICS_FORM.ywid%type; --业务事项编码
  mkm      ZD_STATISTISTICS_FORM.mkm%type; --模块名称
  bdm      ZD_STATISTISTICS_FORM.bdm%type; --表单名称
  bdbh      ZD_STATISTISTICS_FORM.bdbh%type; --表单编码
  tableName ZD_STATISTISTICS_FORM.db_table_name%type;
  flowName  ZD_STATISTISTICS_FORM.Flow_Name%type;
  condition     ZD_STATISTISTICS_FORM.condition%type;
  recordTime date;
  todayAplNum number; -- 今日申请单数
  todayFlwNum number; -- 今日流转中数
  todayEndNum number; -- 今日归档数
  monStartNum number; -- 月累计启动数
  monEndNum number; -- 月累计归档数
begin
  recordTime := sysdate;
  open tableNameCur;
  loop
    fetch tableNameCur
      into  mkm,ywsx, bdbh,bdm,ywid,tableName,flowName,condition ;
    exit when tableNameCur%notfound;
    if tableNameCur%found then
      -- 今日申请单数
      todayAplNum := fun_form_applay_count(organCode,
                                               tableName,
                                               beginTime,
                                               endTime,
                                               condition);
        -- 今日流转中数
       todayFlwNum := fun_form_diliver_count(organCode,
                                               flowName,
                                               tableName,
                                               beginTime,
                                               endTime,
                                               condition);
       -- 今日归档数
       todayEndNum := fun_form_end_count(organCode,
                                               flowName,
                                               tableName,
                                               beginTime,
                                               endTime,
                                               condition);
      -- 月累计启动数
       monStartNum := fun_form_applay_count(organCode,
                                               tableName,
                                               firstDayTime,
                                               endTime,
                                               condition);

       -- 月累计归档数
       monEndNum := fun_form_end_count(organCode,
                                               flowName,
                                               tableName,
                                               firstDayTime,
                                               endTime,
                                               condition);
   
      --中调新增数
      insert into T_TAB_COUNT
        (ID,
         ORGANCODE,
         OPTION_TYPE,
         SQ,
         AREA,
         RECORD_DATE,
         BUSINESS_NAME,
         BUSINESS_CODE,
         MODULE_NAME,
         TABLE_NAME,
         TABLE_CODE,
         TODAY_APL_NUM,
         TODAY_FLW_NUM,
         TODAY_END_NUM,
         MON_START_NUM,
         MON_END_NUM,
         RECORD_TIME)
      values
        (sys_guid(),
         organCode,
         optionType,
         sq,
         area,
         recordTime,
         ywsx,
         ywid,
         mkm,
         bdm,
         bdbh,
         todayAplNum,
         todayFlwNum,
         todayEndNum,
         monStartNum,
         monEndNum,
         recordTime
         );
    end if;
  end loop;
  close tableNameCur;
end PRO_FORM_STATISTISTICS;

/
