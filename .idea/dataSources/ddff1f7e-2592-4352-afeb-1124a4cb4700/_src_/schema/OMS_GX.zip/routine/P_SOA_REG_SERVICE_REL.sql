CREATE PROCEDURE P_soa_reg_service_REL(serviceCode  VARCHAR2, dirCode  VARCHAR2, sysCode VARCHAR2) IS
/******************************************************************************
   NAME:       P_soa_reg_service_REL
   PURPOSE:    服务关联注册存储过程

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2015/2/5   lixiaoqiang       1. Created this procedure.

   NOTES:自动将服务与目录、业务系统进行关联，规则是服务编号、目录编号、业务系统编号组合不重复。先根据条件进行删除，再新增

******************************************************************************/
BEGIN
 delete SOA_SERVICE_RELATE_DIR where SERVICE_CODE  =serviceCode and DIR_CODE =dirCode and SYS_CODE=sysCode;
 insert into SOA_SERVICE_RELATE_DIR (SERVICE_CODE,DIR_CODE ,SYS_CODE) values (serviceCode,dirCode,sysCode);
 commit;
END P_soa_reg_service_REL;

/
