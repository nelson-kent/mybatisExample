CREATE PROCEDURE p_soa_reg_Params (
  paramCode VARCHAR2,methodCode VARCHAR2,paramName VARCHAR2,
  paramType NUMBER, paramSeq NUMBER, paramClass VARCHAR2,
  paramFileCode VARCHAR2,paramClassImpl VARCHAR2) IS
couNum NUMBER;
/******************************************************************************
   NAME:       p_soa_reg_localParams
   PURPOSE:    内部服务元素参数存储过程
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2014-2-13    李小强          Created procedure.
******************************************************************************/
BEGIN
    --删除参数信息表
    delete SOA_PARAM where PARAM_CODE =paramCode;
    --删除参数关联信息表
    delete SOA_PARAM_DETAIL det where det.PARAM_CODE = paramCode;
    --插入新的参数信息
    insert into SOA_PARAM(PARAM_CODE,METHOD_CODE,PARAM_NAME,PARAM_TYPE,PARAM_SEQ,PARAM_CLASS,PARAM_FILE_CODE,PARAM_CLASS_PARSER_IMPL)
        values (paramCode,methodCode,paramName, paramType, paramSeq, paramClass, paramFileCode,paramClassImpl);
END p_soa_reg_Params;

/
