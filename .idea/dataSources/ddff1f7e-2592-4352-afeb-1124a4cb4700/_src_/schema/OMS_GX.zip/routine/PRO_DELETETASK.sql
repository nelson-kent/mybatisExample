CREATE procedure PRO_deleteTask(tableName varchar2,trh_tablename varchar2,mainProcessInsId varchar2) as
  content       varchar2(1000);
  lenth         number(10);
  defaultColumn varchar2(1000);
  varsql        varchar2(4000);
begin
  for column_name_temp in (select '''[' || column_name || ':''||' ||
                                  column_name || '||' || ''']' || '''' || '||' as col_des
                             from (SELECT COLUMN_NAME
                                     FROM user_tab_columns
                                    WHERE TABLE_NAME = '' || tableName || ''
                                   MINUS
                                   SELECT COLUMN_NAME
                                     FROM user_tab_columns
                                    WHERE TABLE_NAME = '' || trh_tablename || ''
                                      AND COLUMN_NAME <> 'EXTEND_COL')) loop
    content := content || column_name_temp.col_des;
  end loop;

  SELECT bpms_oracle_wm_concat(col_des) new_result
    into defaultColumn
    FROM (select column_name as col_des
            from user_tab_columns
           WHERE TABLE_NAME ='' || trh_tablename || ''
             AND COLUMN_NAME <> 'EXTEND_COL');

  lenth := LENGTH(content);
  IF (lenth > 0) then
    content := SUBSTR(content, 0, lenth - 2);
    content := ',' || content;
  ELSE
    content := ',' || '''' || '''';
  END IF;

  varsql := 'insert into '||trh_tablename||' (' || defaultColumn || ',EXTEND_COL)' ||
            'select ' || defaultColumn || content || ' from ' || tableName || ' where main_process_ins_id =''' || mainProcessInsId || '''';
  execute immediate varsql;
  --COMMIT;
end PRO_deleteTask;

/
