CREATE PROCEDURE Pro_edit_userProcessTask(processId varchar2) IS

/******************************************************************************
   NAME:       Pro_edit_userProcessTask
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2012-12-26     李小强    统计某一流程下的用户任务数并更新到用户流程任务表中
******************************************************************************/
 exeSQL            varchar2(1000); --要执行SQL语句
 redef_table_num   number(1); ---是否存在分表
 table_name        varchar2(50); --待办任务所对应的表名
BEGIN
 --1、处理分表信息
 select count(1) into redef_table_num  from BPMS_CFG_REDEF_TABLE t1  where t1.PROCESS_ID = '' || processId || '';
 if redef_table_num > 0 then
    select 'BPMS_RU_TODO_TASK_'|| suffix_flag  into table_name from BPMS_CFG_REDEF_TABLE where process_id='' || processId || '';
 end if;
 if redef_table_num <= 0 then
   table_name:='BPMS_RU_TODO_TASK';
 end if;
 --2、删除现有的流程用户任务
delete bpms_stats_user_Process_task where process_id='' || processId || '';
--3、组合统计SQL:

insert into bpms_stats_user_Process_task   select   trans_actor_id ,processId,count(1) total_task from BPMS_RU_TODO_TASK
  where main_process_id='' || processId || '' group by trans_actor_id;


--exeSQL:='select trans_actor_id ,count(1) total_task from'|| table_name ||'where main_process_id='''||processId||''' group by trans_actor_id';
--for table_tmp in ( select trans_actor_id ,count(1) total_task from BPMS_RU_TODO_TASK where main_process_id=''||processId||'' group by trans_actor_id ) loop

--for table_tmp in ( execute immediate exeSQL ) loop
  --insert into bpms_stats_user_Process_task values (SEQ_STATS_USER_PROCESS_TASK.nextval,table_tmp.trans_actor_id,processId,table_tmp.total_task);
--end loop;


END Pro_edit_userProcessTask;

/
