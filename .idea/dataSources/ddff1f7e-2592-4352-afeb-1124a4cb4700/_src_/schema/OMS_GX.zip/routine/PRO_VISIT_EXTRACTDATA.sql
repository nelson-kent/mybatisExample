CREATE procedure pro_visit_extractdata(c_date varchar2) is
  tempsql   varchar2(30000);
  starttime varchar2(20);
  endtime   varchar2(20);
  /*****************************************************************************
        DATE：2013.11.15
        purpose：获得每个用户在一段时间内的访问次数及登陆总时长。

  *******************************************************************************/
begin
  starttime := c_date;
  --结束时间等于开始时间+1天
  endtime := to_char((to_date(c_date, 'yyyy-MM-dd  HH24:mi:ss') + 1),
                     'yyyy-MM-dd hh24:mi:ss');
  --先删除表中今天统计的部门登录次数，防止重复插入
  DELETE FROM TOP_USER_VISIT_DATA WHERE STATISTICS_TIME = to_date(starttime, 'yyyy-mm-dd HH24:mi:ss');

  tempsql := 'insert into TOP_USER_VISIT_DATA (USER_VISIT_DATA_ID,USER_ID,
     USER_NAME, ORG_ID, ORG_NAME,STATISTICS_TIME, LOGIN_COUNT, TOTAL_TIME)
     SELECT sys_guid(),user_id, user_name, ORG_ID, org_name,statistics_time, login_count, total_time
     FROM (
         select t.user_id,t.user_name,t.org_id,t.org_name,
         to_date(''' || starttime || ''', '' yyyy-mm-dd HH24:mi:ss '') statistics_time,
         count(t.user_id) login_count,
         decode(sum((tlu.exit_time-tlu.login_time)*24),null,0,
                sum((tlu.exit_time-tlu.login_time)*24)) total_time
         from (
           select *
           from top_log_user_operate
           where OPERATE_TYPE = 1
         ) t,top_log_user_login_detail tlu
         where t.operate_id = tlu.operate_id
           and tlu.login_time >= to_date(:1, ''yyyy-mm-dd HH24:mi:ss '')
           and tlu.exit_time < to_date(:2, ''yyyy-mm-dd HH24:mi:ss'')
           and tlu.exit_time is not null
           group by t.user_id,t.user_name,t.org_id,t.org_name)
     WHERE login_count > 0 or total_time > 0';



  execute immediate tempsql  using starttime, endtime;
  commit;
exception
  when others then
    rollback;
end pro_visit_extractdata;

/
