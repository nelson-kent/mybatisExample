CREATE FUNCTION my_sin(DegreesIn IN NUMBER)
 RETURN NUMBER
IS
pi NUMBER=ACOS(-1);
 RadiansPerDegree NUMBER;
BEGIN
 RadiansPerDegree=pi/180;
RETURN(SIN(DegreesIn*RadiansPerDegree));
END
  /
