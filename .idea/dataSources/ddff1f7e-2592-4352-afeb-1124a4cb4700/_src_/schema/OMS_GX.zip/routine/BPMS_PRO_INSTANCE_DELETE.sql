CREATE PROCEDURE BPMS_PRO_INSTANCE_DELETE(processId        varchar2,
                                              mainProcessInsId varchar2) AUTHID CURRENT_USER IS

  /******************************************************************************
     NAME:       BPMS_PRO_INSTANCE_DELETE
     PURPOSE:  (根据流程ID、流程实例ID进行数据删除)

     REVISIONS:
     Ver        Date        Author           Description
     ---------  ----------  ---------------  ------------------------------------
     1.0        2015-02-02          1. Created this procedure.

     NOTES:

     Automatically available Auto Replace Keywords:
        Object Name:     BPMS_PRO_INSTANCE_DELETE 流程实例数据删除
        Sysdate:         2015-02-02
        Date and Time:   2015-02-02, 14:43:40, and 2015-02-02 14:43:40
        Username:         (set in TOAD Options, Procedure Editor)
        Table Name:       (set in the "New PL/SQL Object" dialog)

  ******************************************************************************/
  process_redef_table_name varchar2(10); --记录流程定义所对应的分表后缀名
  redef_table_num          number(1); ---是否存在分表
  exeSQL                   varchar2(1000); --要执行SQL语句

  BPMS_RU_CC_TASK_TABLE     VARCHAR2(100); --抄送任务表名
  BPMS_RU_DONE_TASK_TABLE   VARCHAR2(100); --已办表名
  BPMS_RU_NODE_TRACK_TABLE  VARCHAR2(100); --节点跟踪表名
  BPMS_RU_PROCESS_INS_TABLE VARCHAR2(100); --流程实例表名
  BPMS_RU_TODO_TASK_TABLE   VARCHAR2(100); --待办表名
  BPMS_RU_VAR_TABLE         VARCHAR2(100); --变量表名

  BPMS_RU_ACTIVE_INS_TABLE  VARCHAR2(100); --活动实例表名
  BPMS_RU_NODE_ORBIT_TABLE  VARCHAR2(100); --节点轨迹表名
  BPMS_RU_TRANS_TRACK_TABLE VARCHAR2(100); --处理跟踪表名
  BPMS_RU_NODE_INS_TABLE VARCHAR2(100); --节点实例表名
  BPMS_RU_ATTACHMENT_TABLE VARCHAR2(100); --审批附件基本信息表名
  BPMS_RU_REVOKE_LOG_TABLE VARCHAR2(100); --流程撤回日志记录表名
  BPMS_RU_TODO_TASK_ALL_TABLE VARCHAR2(100); --待办任务总表表名
  BPMS_RU_COMPEVENT_INS_TB VARCHAR2(100); --补偿事件实例表名
  BPMS_RU_COMPEVENT_SUS_TB VARCHAR2(100); --补偿事件订阅表名
  BPMS_RU_MESEVENT_SUS_TABLE VARCHAR2(100); --消息事件订阅表名
  BPMS_RU_MESEVENT_TRI_TABLE VARCHAR2(100); --消息事件触发表表名
  BPMS_RU_SIGEVENT_TRI_TABLE VARCHAR2(100); --信号事件实例表表名
  BPMS_RU_SIGNEVENT_SUS_TABLE VARCHAR2(100); --信号事件订阅表表名

BEGIN

  if processId is not null then
    if mainProcessInsId is not null then

      select count(1) into redef_table_num  from BPMS_CFG_REDEF_TABLE t1 where t1.PROCESS_ID = '' || processId || '';

      --step1:分析流程分表信息，准备源数据表名
      if redef_table_num > 0 then
        --当用户有对此流程定义分表时，加上分表后缀
        select t2.SUFFIX_FLAG into process_redef_table_name from BPMS_CFG_REDEF_TABLE t2 where t2.PROCESS_ID = '' || processId || '';

        BPMS_RU_CC_TASK_TABLE     := 'BPMS_RU_CC_TASK_' || process_redef_table_name;
        BPMS_RU_DONE_TASK_TABLE   := 'BPMS_RU_DONE_TASK_' || process_redef_table_name;
        BPMS_RU_NODE_TRACK_TABLE  := 'BPMS_RU_NODE_TRACK_' || process_redef_table_name;
        BPMS_RU_PROCESS_INS_TABLE := 'BPMS_RU_PROCESS_INS_' || process_redef_table_name;
        BPMS_RU_TODO_TASK_TABLE   := 'BPMS_RU_TODO_TASK_' || process_redef_table_name;
        BPMS_RU_VAR_TABLE         := 'BPMS_RU_VAR_' || process_redef_table_name;
        BPMS_RU_ACTIVE_INS_TABLE  := 'BPMS_RU_ACTIVE_INS_' || process_redef_table_name;
        BPMS_RU_NODE_ORBIT_TABLE  := 'BPMS_RU_NODE_ORBIT_' || process_redef_table_name;
        BPMS_RU_TRANS_TRACK_TABLE := 'BPMS_RU_TRANS_TRACK_' || process_redef_table_name;
        BPMS_RU_NODE_INS_TABLE    := 'BPMS_RU_NODE_INS_' || process_redef_table_name;
        BPMS_RU_ATTACHMENT_TABLE  := 'BPMS_RU_ATTACHMENT_' || process_redef_table_name;
        BPMS_RU_REVOKE_LOG_TABLE  := 'BPMS_RU_REVOKE_LOG_' || process_redef_table_name;
        BPMS_RU_TODO_TASK_ALL_TABLE:= 'BPMS_RU_TODO_TASK_ALL';
        BPMS_RU_COMPEVENT_INS_TB:='BPMS_RU_COMPEVENT_INS_'|| process_redef_table_name;
        BPMS_RU_COMPEVENT_SUS_TB:='BPMS_RU_COMPEVENT_SUS_'|| process_redef_table_name;
        BPMS_RU_MESEVENT_SUS_TABLE :='BPMS_RU_MESEVENT_SUS_'|| process_redef_table_name;
        BPMS_RU_MESEVENT_TRI_TABLE :='BPMS_RU_MESEVENT_TRI_'|| process_redef_table_name;
        BPMS_RU_SIGEVENT_TRI_TABLE :='BPMS_RU_SIGEVENT_TRI_'|| process_redef_table_name;
        BPMS_RU_SIGNEVENT_SUS_TABLE :='BPMS_RU_SIGNEVENT_SUS_'|| process_redef_table_name;
      else
        --不加后缀，直接查原表
        BPMS_RU_CC_TASK_TABLE     := 'BPMS_RU_CC_TASK';
        BPMS_RU_DONE_TASK_TABLE   := 'BPMS_RU_DONE_TASK';
        BPMS_RU_NODE_TRACK_TABLE  := 'BPMS_RU_NODE_TRACK';
        BPMS_RU_PROCESS_INS_TABLE := 'BPMS_RU_PROCESS_INS';
        BPMS_RU_TODO_TASK_TABLE   := 'BPMS_RU_TODO_TASK';
        BPMS_RU_VAR_TABLE         := 'BPMS_RU_VAR';
        BPMS_RU_ACTIVE_INS_TABLE  := 'BPMS_RU_ACTIVE_INS';
        BPMS_RU_NODE_ORBIT_TABLE  := 'BPMS_RU_NODE_ORBIT';
        BPMS_RU_TRANS_TRACK_TABLE := 'BPMS_RU_TRANS_TRACK';
        BPMS_RU_NODE_INS_TABLE    := 'BPMS_RU_NODE_INS';
        BPMS_RU_ATTACHMENT_TABLE  := 'BPMS_RU_ATTACHMENT';
        BPMS_RU_REVOKE_LOG_TABLE  := 'BPMS_RU_REVOKE_LOG';
        BPMS_RU_TODO_TASK_ALL_TABLE:= 'BPMS_RU_TODO_TASK_ALL';
        BPMS_RU_COMPEVENT_INS_TB:='BPMS_RU_COMPEVENT_INS';
        BPMS_RU_COMPEVENT_SUS_TB:='BPMS_RU_COMPEVENT_SUS';
        BPMS_RU_MESEVENT_SUS_TABLE :='BPMS_RU_MESEVENT_SUS';
        BPMS_RU_MESEVENT_TRI_TABLE :='BPMS_RU_MESEVENT_TRI';
        BPMS_RU_SIGEVENT_TRI_TABLE :='BPMS_RU_SIGEVENT_TRI';
        BPMS_RU_SIGNEVENT_SUS_TABLE :='BPMS_RU_SIGNEVENT_SUS';
      end if;
      --step2: 拼装并删除实例数据

      --删除:信号事件订阅表数据
      exeSQL := 'delete from '|| BPMS_RU_SIGNEVENT_SUS_TABLE||
            ' a where a.main_process_ins_id ='''||mainProcessInsId || '''';
      execute immediate exeSQL;
      --删除信号事件实例表数据
      exeSQL := 'delete from '||BPMS_RU_SIGEVENT_TRI_TABLE||
            ' a where a.main_process_ins_id ='''||mainProcessInsId || '''';
      execute immediate exeSQL;
      --删除消息事件触发表数据
      exeSQL := 'delete from '||BPMS_RU_MESEVENT_TRI_TABLE||
            ' a where a.main_process_ins_id ='''||mainProcessInsId || '''';
      execute immediate exeSQL;
      --删除消息事件订阅表数据
      exeSQL := 'delete from '|| BPMS_RU_MESEVENT_SUS_TABLE||
            ' a where a.main_process_ins_id ='''||mainProcessInsId || '''';
      execute immediate exeSQL;
      --删除补偿事件订阅表数据
      exeSQL := 'delete from '|| BPMS_RU_COMPEVENT_SUS_TB||
            ' a where a.main_process_ins_id ='''||mainProcessInsId || '''';
      execute immediate exeSQL;
      --删除信号事件实例表数据
      exeSQL := 'delete from '|| BPMS_RU_COMPEVENT_INS_TB||
            ' a where a.main_process_ins_id ='''||mainProcessInsId || '''';
      execute immediate exeSQL;
      --删除待办任务总表数据
      exeSQL := 'delete from '||BPMS_RU_TODO_TASK_ALL_TABLE||
            ' a where exists(select 1 from '||BPMS_RU_ACTIVE_INS_TABLE||
            ' b where a.activity_ins_id = b.activity_ins_id and exists( select 1 from '||BPMS_RU_NODE_INS_TABLE||
            ' c where b.node_ins_id = c.node_ins_id and c.main_process_ins_id ='''||mainProcessInsId || '''))';
      execute immediate exeSQL;
      --删除:流程撤回日志记录表数据
      exeSQL := 'delete from ' || BPMS_RU_REVOKE_LOG_TABLE||
            ' a where exists(select 1 from '||BPMS_RU_ACTIVE_INS_TABLE||
            ' b where a.activity_ins_id = b.activity_ins_id and exists( select 1 from '||BPMS_RU_NODE_INS_TABLE||
            ' c where b.node_ins_id = c.node_ins_id and c.main_process_ins_id ='''||mainProcessInsId || '''))';
      execute immediate exeSQL;
      --删除：审批附件信息表数据
      exeSQL := 'delete from ' || BPMS_RU_ATTACHMENT_TABLE||
            ' a where exists(select 1 from '||BPMS_RU_ACTIVE_INS_TABLE||
            ' b where a.act_ins_id = b.activity_ins_id and exists( select 1 from '||BPMS_RU_NODE_INS_TABLE||
            ' c where b.node_ins_id = c.node_ins_id and c.main_process_ins_id ='''||mainProcessInsId || '''))';
      execute immediate exeSQL;

      --删除抄送数据
      exeSQL := ' delete from ' ||
                BPMS_RU_CC_TASK_TABLE ||
                ' c where c.main_process_ins_id =''' || mainProcessInsId || '''';
      execute immediate exeSQL;
      --删除已办任务数据
      exeSQL := ' delete from ' ||
                BPMS_RU_DONE_TASK_TABLE ||
                ' c where c.main_process_ins_id =''' || mainProcessInsId || '''';
      execute immediate exeSQL;
      --删除节点跟踪数据
      exeSQL := ' delete from ' ||
                BPMS_RU_NODE_TRACK_TABLE ||
                ' k where k.main_process_ins_id =''' || mainProcessInsId || '''
                  and k.CUR_PROCESS_ID =''' || processId || '''';
      execute immediate exeSQL;
      --删除流程实例数据
      exeSQL := 'delete from ' ||
                BPMS_RU_PROCESS_INS_TABLE ||
                ' p where p.main_process_ins_id =''' || mainProcessInsId || '''';
      execute immediate exeSQL;
      --删除待办任务数据
      exeSQL := 'delete from ' ||
                BPMS_RU_TODO_TASK_TABLE ||
                ' t where t.main_process_ins_id =''' || mainProcessInsId || '''';
      execute immediate exeSQL;
      --删除变量数据
      exeSQL := 'delete from ' ||
                BPMS_RU_VAR_TABLE || ' v where v.main_process_ins_id =''' ||
                mainProcessInsId || '''';
      execute immediate exeSQL;

      --删除活动实例数据
      exeSQL := ' delete from ' || BPMS_RU_ACTIVE_INS_TABLE ||
                ' a where exists (select 1  from ' ||
                BPMS_RU_NODE_INS_TABLE ||
                ' n where a.node_ins_id = n.node_ins_id and n.main_process_ins_id =''' ||
                mainProcessInsId || ''')';
      execute immediate exeSQL; --执行删除活动实例表数据,

      --删除节点轨迹表数据
      exeSQL := 'delete from ' ||
                BPMS_RU_NODE_ORBIT_TABLE ||
                ' o where exists (select 1  from ' ||
                BPMS_RU_NODE_INS_TABLE ||
                ' n where o.cur_node_ins_id = n.node_ins_id and n.main_process_ins_id =''' ||
                mainProcessInsId || ''')';
      execute immediate exeSQL;
      --删除办理跟踪明细数据
      exeSQL := 'delete from ' ||
                BPMS_RU_TRANS_TRACK_TABLE ||
                ' r where exists (select 1  from ' ||
                BPMS_RU_NODE_INS_TABLE ||
                ' n where r.node_ins_id = n.node_ins_id and n.main_process_ins_id =''' ||
                mainProcessInsId || ''' and r.PROCESS_ID =''' || processId || ''')';
      execute immediate exeSQL;

      --删除节点实例数据
      exeSQL := 'delete from ' ||
                BPMS_RU_NODE_INS_TABLE ||
                ' n where n.main_process_ins_id = ''' || mainProcessInsId || '''';
      execute immediate exeSQL;

    end if;
  end if;
END BPMS_PRO_INSTANCE_DELETE;

/
