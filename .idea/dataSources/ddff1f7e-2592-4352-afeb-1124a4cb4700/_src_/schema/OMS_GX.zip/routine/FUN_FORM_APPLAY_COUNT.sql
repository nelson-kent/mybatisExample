CREATE FUNCTION fun_form_applay_count(orgCode       in varchar2,
                                                   tableName     in varchar2,
                                                   beginTim      in varchar2,
                                                   endTIime      in varchar2,
                                                   condition in varchar2)
  RETURN NUMBER IS
  sumCount number;
  sumStr   varchar2(1000);
  p_sqlerrm VARCHAR2(1000);
BEGIN
   if tableName is null then
     return 0;
   end if;
   sumStr := 'select count(*) from ' || tableName ||
            ' where create_time> to_date(''' || beginTim ||
            ''',''yyyy-MM-dd HH24:mi:ss'')
             and create_time<= to_date(''' || endTIime ||
            ''',''yyyy-MM-dd HH24:mi:ss'') and creator_id in (
      select  use.employee_id from top_user use  where use.org_id in(
            select org.org_id from top_organization org where   org.org_code like ''' ||
            orgCode || '%''))';
  if condition is not null  then
      sumStr := sumStr || ' and '||condition;
  end if;
  EXECUTE IMMEDIATE sumStr INTO sumCount;
   --四遥一条记录当三条，这个要确认。
  if tableName = 'OMS_SS_BASEBUILDENTER' then
    sumCount := sumCount * 3;
  end if;
  return nvl(sumCount,0);
  exception when others then
    p_sqlerrm := tableName||'表查询异常'||sqlerrm; --错误信息显示
     insert into PRO_FUN_RUN_LOG
      (p_name, p_date, p_time, p_sqlerrm, p_error)
    values
      ('fun_form_applay_count', --存储过程名称
       sysdate, --数据日期
       to_char(sysdate, 'YYYY-MM-DD HH:MI:SS'), --跑批时间
       p_sqlerrm, --错误信息
       dbms_utility.format_error_backtrace() --错误位置
       );
    commit;
    return 0;
END fun_form_applay_count;

/
