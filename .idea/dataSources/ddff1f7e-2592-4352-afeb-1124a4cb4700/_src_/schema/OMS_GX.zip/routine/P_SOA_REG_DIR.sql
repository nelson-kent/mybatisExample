CREATE PROCEDURE P_SOA_REG_DIR (dirFullPath in VARCHAR2)IS
   /******************************************************************************
      NAME:       P_SOA_REG_DIR
      PURPOSE:    服务目录数据注册处理
      REVISIONS: 在服务注册时，服务类注册存储过程调用此功能，用于创建指定服务全路径的服务目录数据
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        2014-2-11    李小强          Created this procedure.
   ******************************************************************************/
   pathLevel number (2);--路径层级
   DIR_TEMP_PATH   VARCHAR2 (2000);--临时路径
   countNum number(2);--统计个数
   parentDirCode varchar2(40);--上级目录编号
   lastCharIndex number(5);
   DIR_FULL_PATH_new varchar2(2000);--新的目录全路径
   parentDirPath varchar2(2000);--上级路径
 BEGIN
  --第一步分析服务目录是否为空。为空则直接返回
 if dirFullPath is not null then
     DIR_FULL_PATH_new:=dirFullPath;
     if substr(dirFullPath,-1, 1) !='/' then
       DIR_FULL_PATH_new:=DIR_FULL_PATH_new||'/';
    end if ;
    --第一步：算出层次数
    select length(DIR_FULL_PATH_new)-length(replace(DIR_FULL_PATH_new,'/','')) into pathLevel from dual;

       for i in 1  .. pathLevel loop

          SELECT substr(DIR_FULL_PATH_new, 0, INSTR(DIR_FULL_PATH_new, '/',1, i)-1) into DIR_TEMP_PATH FROM DUAL;
          --dbms_output.put_line('DIR_TEMP_PATH: '||DIR_TEMP_PATH);
          select count(1) INTO countNum from soa_dir where DIR_FULL_PATH =DIR_TEMP_PATH;
          if countNum<1 then

             select substr(DIR_TEMP_PATH, 0,INSTR(DIR_TEMP_PATH, '/',-1, 1)-1) into parentDirPath FROM DUAL;

             select count(1) into countNum from soa_dir where DIR_FULL_PATH = parentDirPath;

             if countNum>0 then--如果存在，则直接添加
                select DIR_CODE into parentDirCode from soa_dir where DIR_FULL_PATH =parentDirPath;
             end if;
             select INSTR(DIR_TEMP_PATH, '/',-1, 1) into lastCharIndex from dual;
             if lastCharIndex>0 then
                lastCharIndex :=lastCharIndex+1;
             end if;
             insert into  SOA_DIR(DIR_CODE,DIR_NAME,PARENT_DIR_CODE,DIR_FULL_PATH) values (sys_guid() ,substr(DIR_TEMP_PATH, lastCharIndex) ,parentDirCode,DIR_TEMP_PATH);

         end if;
         commit;
      END LOOP;
 end if;
END P_SOA_REG_DIR;

/
