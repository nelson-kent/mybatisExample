CREATE FUNCTION getProfession(factoryname in varchar2)
return  varchar2
as

begin
  for v in (select * from OMS_OE_DEVICE_FACTORY_INFO F where F.Device_Factory =factoryname)loop
  return v.Profession;

   end loop;
end;

/
