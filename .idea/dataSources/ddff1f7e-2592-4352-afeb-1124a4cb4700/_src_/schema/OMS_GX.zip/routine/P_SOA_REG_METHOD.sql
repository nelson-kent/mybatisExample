CREATE PROCEDURE P_SOA_REG_Method(
  methodCode VARCHAR2,methodAlias VARCHAR2,methodName VARCHAR2,serviceCode VARCHAR2,asyn NUMBER,timeouts NUMBER,paramParser varchar2) IS
countNum number(1);--统计数据
/******************************************************************************
   NAME:       P_SOA_REG_Method
   PURPOSE:  保存服务元素（方法）的存储过程

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2014-2-13    李小强          Created this procedure.

******************************************************************************/
BEGIN
--删除服务方法
 delete SOA_METHOD where method_CODE = methodCode;

 --删除参数关联信息
 delete SOA_PARAM_DETAIL det where det.PARAM_CODE in(select para.PARAM_CODE from SOA_PARAM para where para.METHOD_CODE = methodCode);

 --删除服务类所对应的参数信息
 delete SOA_PARAM where METHOD_CODE =methodCode;

 insert into SOA_METHOD(METHOD_CODE ,METHOD_ALIAS ,METHOD_NAME,SERVICE_CODE,IS_ASYN,TIME_OUTS ,PARAM_PARSER)
                    values (methodCode,methodAlias,methodName,serviceCode,asyn,timeouts,paramParser);


 insert into SOA_REGISTER_LOG(METHOD_CODE,SERVICE_CODE,LOG_TIME,LOG_LEVEL,CLASS_NAME,METHOD_NAME,CODE_LINE,OVERHEAD_TIME, LOG_CONTENT)
 values (methodCode,serviceCode,sysdate,1,'ClassRegister',methodName,20,1,'');
END P_SOA_REG_Method;

/
