CREATE PROCEDURE P_soa_delete_method(methodCode varchar2) AUTHID CURRENT_USER is
PRAGMA AUTONOMOUS_TRANSACTION;

/******************************************************************************
   NAME:       Pro_createTable_NotExist
   PURPOSE:    删除指定的SOA服务（包括南网服务及本地服务）
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2014-8-13      李小强        1. Created this procedure
******************************************************************************/
BEGIN
--删除soa_webservice
delete from soa_webservice  w where w.method_code =methodCode;
--删除soa_param_detail
delete from soa_param_detail pd where pd.param_code in (select p.param_code from soa_param p where p.method_code =methodCode);
--删除soa_param
delete from soa_param p where p.method_code =methodCode;
--删除soa_method
delete from soa_method m  where m.method_code=methodCode;
commit;
END P_soa_delete_method;

/
