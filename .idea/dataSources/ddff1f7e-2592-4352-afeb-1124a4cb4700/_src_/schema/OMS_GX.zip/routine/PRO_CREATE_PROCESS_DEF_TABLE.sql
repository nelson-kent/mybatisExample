CREATE PROCEDURE PRO_CREATE_PROCESS_DEF_TABLE(SUFFIX_FLAG varchar2,USER_NAME varchar2) AUTHID CURRENT_USER is

/******************************************************************************
   NAME:       PRO_CREATE_PROCESS_DEF_TABLE
   PURPOSE:    用户分表的处理，动态创建流程表后缀

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2012-9-10    李小强 1.       Created this procedure.
******************************************************************************/
BEGIN
	Pro_createTable_NotExist('BPMS_RU_CC_TASK',SUFFIX_FLAG,USER_NAME);
	Pro_createTable_NotExist('BPMS_RU_DONE_TASK',SUFFIX_FLAG,USER_NAME);
	Pro_createTable_NotExist('BPMS_RU_NODE_TRACK',SUFFIX_FLAG,USER_NAME);
	Pro_createTable_NotExist('BPMS_RU_PROCESS_INS',SUFFIX_FLAG,USER_NAME);
	Pro_createTable_NotExist('BPMS_RU_TODO_TASK',SUFFIX_FLAG,USER_NAME);
	Pro_createTable_NotExist('BPMS_RU_VAR',SUFFIX_FLAG,USER_NAME);
	Pro_createTable_NotExist('BPMS_RU_ACTIVE_INS',SUFFIX_FLAG,USER_NAME);
	Pro_createTable_NotExist('BPMS_RU_NODE_ORBIT',SUFFIX_FLAG,USER_NAME);
	Pro_createTable_NotExist('BPMS_RU_TRANS_TRACK',SUFFIX_FLAG,USER_NAME);
	Pro_createTable_NotExist('BPMS_RU_NODE_INS',SUFFIX_FLAG,USER_NAME);
	Pro_createTable_NotExist('BPMS_RU_ATTACHMENT',SUFFIX_FLAG,USER_NAME);
	Pro_createTable_NotExist('BPMS_RU_REVOKE_LOG',SUFFIX_FLAG,USER_NAME);
	Pro_createTable_NotExist('BPMS_RU_COMPEVENT_INS',SUFFIX_FLAG,USER_NAME);
	Pro_createTable_NotExist('BPMS_RU_COMPEVENT_SUS',SUFFIX_FLAG,USER_NAME);
	Pro_createTable_NotExist('BPMS_RU_MESEVENT_SUS',SUFFIX_FLAG,USER_NAME);
	Pro_createTable_NotExist('BPMS_RU_MESEVENT_TRI',SUFFIX_FLAG,USER_NAME);
	Pro_createTable_NotExist('BPMS_RU_SIGEVENT_TRI',SUFFIX_FLAG,USER_NAME);
	Pro_createTable_NotExist('BPMS_RU_SIGNEVENT_SUS',SUFFIX_FLAG,USER_NAME);

END PRO_CREATE_PROCESS_DEF_TABLE;

/
