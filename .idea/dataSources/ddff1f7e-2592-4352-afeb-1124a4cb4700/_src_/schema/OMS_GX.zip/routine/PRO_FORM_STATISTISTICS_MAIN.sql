CREATE PROCEDURE PRO_FORM_STATISTISTICS_MAIN
is
beginTime  varchar2(100); -- 开始时间
endTime   varchar2(100);--结束时间
firstDayTime varchar2(100);--每个月的第一天
begin
   endTime := to_char(sysdate,'yyyy-MM-dd HH24:mi:ss');
   beginTime := to_char(sysdate-1,'yyyy-MM-dd HH24:mi:ss');
   select to_char(trunc(add_months(last_day(sysdate), -1) )+1, 'yyyy-mm-dd') ||' 00:00:00'  into firstDayTime  from  dual ;
   dbms_output.put_line('中调统计开始---');
   PRO_FORM_STATISTISTICS(beginTime,endTime,firstDayTime,'0460','Add','广西','中调'); --广西中调
   dbms_output.put_line('柳州统计开始---');
   PRO_FORM_STATISTISTICS(beginTime,endTime,firstDayTime,'0402','Add','广西','柳州'); --广西柳州
   dbms_output.put_line('河池统计开始---');
   PRO_FORM_STATISTISTICS(beginTime,endTime,firstDayTime,'0405','Add','广西','河池'); --广西河池
   commit;
   dbms_output.put_line('桂林统计开始---');
   PRO_FORM_STATISTISTICS(beginTime,endTime,firstDayTime,'0403','Add','广西','桂林'); --广西桂林
   dbms_output.put_line('梧州统计开始---');
   PRO_FORM_STATISTISTICS(beginTime,endTime,firstDayTime,'0408','Add','广西','梧州'); --广西梧州
   dbms_output.put_line('贺州统计开始---');
   PRO_FORM_STATISTISTICS(beginTime,endTime,firstDayTime,'0414','Add','广西','贺州'); --广西贺州
   commit;
   dbms_output.put_line('北海统计开始---');
   PRO_FORM_STATISTISTICS(beginTime,endTime,firstDayTime,'0409','Add','广西','北海'); --广西北海
   dbms_output.put_line('防城港统计开始---');
   PRO_FORM_STATISTISTICS(beginTime,endTime,firstDayTime,'0407','Add','广西','防城港'); --广西防城港
   dbms_output.put_line('玉林统计开始---');
   PRO_FORM_STATISTISTICS(beginTime,endTime,firstDayTime,'0404','Add','广西','玉林'); --广西玉林
   commit;
   dbms_output.put_line('钦州统计开始---');
   PRO_FORM_STATISTISTICS(beginTime,endTime,firstDayTime,'0406','Add','广西','钦州'); --广西钦州
   dbms_output.put_line('贵港统计开始---');
   PRO_FORM_STATISTISTICS(beginTime,endTime,firstDayTime,'0410','Add','广西','贵港'); --广西贵港
   dbms_output.put_line('崇左统计开始---');
   PRO_FORM_STATISTISTICS(beginTime,endTime,firstDayTime,'0411','Add','广西','崇左'); --广西崇左
   commit;
   
   dbms_output.put_line('来宾统计开始---');
   PRO_FORM_STATISTISTICS(beginTime,endTime,firstDayTime,'0412','Add','广西','来宾'); --广西来宾
   dbms_output.put_line('百色统计开始---');
   PRO_FORM_STATISTISTICS(beginTime,endTime,firstDayTime,'0413','Add','广西','百色'); --广西百色
   dbms_output.put_line('南宁统计开始---');
   PRO_FORM_STATISTISTICS(beginTime,endTime,firstDayTime,'0401','Add','广西','南宁'); --广西南宁
   commit;
end PRO_FORM_STATISTISTICS_MAIN;

/
