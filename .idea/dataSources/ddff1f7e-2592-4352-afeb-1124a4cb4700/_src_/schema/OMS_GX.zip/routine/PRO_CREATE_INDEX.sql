CREATE PROCEDURE PRO_CREATE_INDEX(tableName   varchar2,
                                          columnName  varchar2,
                                          code varchar2,i number) AUTHID CURRENT_USER is
  /******************************************************************************
     NAME:       PRO_CREATE_PK_AND_INDEX
     PURPOSE:    给分表创建索引

     REVISIONS:
     Ver        Date        Author           Description
     ---------  ----------  ---------------  ------------------------------------
     1.0        2014-11-20    翟羽佳       Created this procedure.
  ******************************************************************************/
  newTableName    varchar2(40); ---新的表名
  varSql          varchar2(1000); ---动态sql
  existCount      number(4); ---是否存在标示
  indexName       varchar2(40);
  preCode         varchar2(40);

BEGIN
    newTableName := tableName || '_' || code;
    preCode:=substr(newTableName,9,30);
   --创建索引,先查再加
   indexName:=preCode||'_i_'||i;
   select count(*) into existCount from user_indexes w where w.index_name =upper(indexName);
   if existCount=0 then
   varSql:=' create index '||indexName||' on '||newTableName||'('||columnName||')';
   execute immediate varSql;
   end if;
END PRO_CREATE_INDEX;

/
