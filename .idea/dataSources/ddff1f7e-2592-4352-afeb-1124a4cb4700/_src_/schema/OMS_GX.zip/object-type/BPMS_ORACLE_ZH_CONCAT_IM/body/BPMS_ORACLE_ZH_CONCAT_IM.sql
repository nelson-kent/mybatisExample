CREATE TYPE BODY bpms_oracle_zh_concat_im
IS
  STATIC FUNCTION ODCIAGGREGATEINITIALIZE(SCTX IN OUT bpms_oracle_zh_concat_im)
  RETURN NUMBER
  IS
  BEGIN
    SCTX := bpms_oracle_zh_concat_im(NULL) ;
    RETURN ODCICONST.SUCCESS;
  END;
  MEMBER FUNCTION ODCIAGGREGATEITERATE(SELF IN OUT bpms_oracle_zh_concat_im,
          P1 IN VARCHAR2)
  RETURN NUMBER
  IS
  BEGIN
    IF(CURR_STR IS NOT NULL) THEN
      CURR_STR := CURR_STR || ',' || P1;          --字段间分隔符,根据实际情况替换(一共有两个地方，这是第一个地方)
    ELSE
      CURR_STR := P1;
    END IF;
    RETURN ODCICONST.SUCCESS;
  END;
  MEMBER FUNCTION ODCIAGGREGATETERMINATE(SELF IN bpms_oracle_zh_concat_im,
                                 RETURNVALUE OUT VARCHAR2,
                                 FLAGS IN NUMBER)
    RETURN NUMBER
  IS
  BEGIN
    RETURNVALUE := CURR_STR ;
    RETURN ODCICONST.SUCCESS;
  END;
  MEMBER FUNCTION ODCIAGGREGATEMERGE(SELF IN OUT bpms_oracle_zh_concat_im,
                                   SCTX2 IN bpms_oracle_zh_concat_im)
  RETURN NUMBER
  IS
  BEGIN
    IF(SCTX2.CURR_STR IS NOT NULL) THEN
      SELF.CURR_STR := SELF.CURR_STR || ':' || SCTX2.CURR_STR ;  --字段间分隔符,根据实际情况替换(一共有两个地方，这是第2个地方)
    END IF;
    RETURN ODCICONST.SUCCESS;
  END;
END;

/
